package cky_miniproject2;
import java.util.Scanner;
public class SmartPhone {
	
	Scanner in = new Scanner(System.in);
	Addr[] addrArray = new Addr[10];
	Addr Addr = new Addr();
	
	int count=0;

	SmartPhone(){
		
	}
	
	Addr inputAddrData() {				
		System.out.print("이름 : ");
		this.Addr.setAddrName(in.nextLine());
		System.out.print("전화번호 : ");
		this.Addr.setAddrPhoneNo(in.nextLine());
		System.out.print("이메일 : ");
		this.Addr.setAddrMail(in.nextLine());
		System.out.print("주소 : ");
		this.Addr.setAddrAddr(in.nextLine());
		System.out.print("그룹(친구/가족) : ");
		this.Addr.setAddrGroup(in.nextLine());
		return new Addr(Addr.getAddrName(), Addr.getAddrPhoneNo(), Addr.getAddrMail(), Addr.getAddrAddr(), Addr.getAddrGroup());
	}//입력메소드 끝
	
	void addAddr(Addr Addr) {
		printAddr(Addr);
		this.addrArray[count] =Addr;
		System.out.println(">>>> 데이터가 저장되었습니다. ("+(count+1)+")");	
		this.count++;	
	}//저장메소드 끝
	
	void printAddr(Addr Addr) {
		System.out.println("------------------------------------");
		System.out.printf("이름 : %s\n전화번호 : %s\n이메일 : %s\n주소 : %s\n그룹(친구/가족) : %s\n",Addr.getAddrName(), Addr.getAddrPhoneNo(), Addr.getAddrMail(), Addr.getAddrAddr(), Addr.getAddrGroup());
		System.out.println("------------------------------------");
	}//출력메소드 끝
	
	void printAllAddr() {
		for(int i =0; i<this.count; i++) 
			printAddr(addrArray[i]);	
	}//모두출력 메소드 끝	
	
	void searchAddr(String name) {		
		for(int i = 0; i<this.count;i++) {
			if(name.contentEquals(addrArray[i].getAddrName())) {
				printAddr(addrArray[i]);
				return;
			}
		}	
	}//검색메소드 끝
	
	void deleteAddr(String name) {		
		for(int i = 0; i<this.count;i++) {
			if(name.contentEquals(addrArray[i].getAddrName())) {
				for(int j =i; j<this.count-1;j++) {
					this.addrArray[j]=this.addrArray[j+1];					
				}
				this.addrArray[this.count-1] = null;
				this.count --;
				printAllAddr();
				return;
			}
		}
		
	}//삭제메소드 끝
	
	void editAddr(String name, Addr newAddr) {		
		for(int i = 0; i<this.count;i++) {
			if(name.contentEquals(addrArray[i].getAddrName())) {
				printAddr(addrArray[i]);
				System.out.println("정보를 재입력해주세요.");
				addrArray[i] = newAddr;
				return;
			}
		}
	}//수정메소드 끝	
}
