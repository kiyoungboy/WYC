package cky_miniproject2;
import java.util.Scanner;
public class SmartPhoneMain {

	public static void main(String[] args) {
		Scanner in = new Scanner(System.in);
		String name;
		SmartPhone myPhone = new SmartPhone();

		System.out.println("#데이터 2개를 입력합니다.");
		for(int i = 0; i<2; i++ ) 
			myPhone.addAddr(myPhone.inputAddrData());				
		while(true) {	
			printMenu();
			String selectMenu = in.nextLine();
			switch(selectMenu){
			case "1" : 
				myPhone.addAddr(myPhone.inputAddrData());
				break;
			case "2" : 
				myPhone.printAllAddr();
				break;
			case "3" : 
				System.out.println("찾으실 이름을 입력해주세요");
				name = in.nextLine();
				myPhone.searchAddr(name);			
				break;
			case "4" : 
				System.out.println("삭제할 이름을 입력해주세요");
				name = in.nextLine();
				myPhone.deleteAddr(name);
				break;
			case "5" : 
				System.out.println("수정할 아이디를 입력해주세요.");
				name = in.nextLine();
				myPhone.editAddr(name, myPhone.inputAddrData());
				break;
			case "6" : 
				in.close();
				return; 
				//리턴은 컨튜롤 << 명심.
//				System.exit(0);
			}
		}
	}//메인메소드 끝
	static void printMenu() {
		System.out.println("주소 관리 메뉴--------------------");
		System.out.println(">> 1. 연락처 등록");
		System.out.println(">> 2. 모든 연락처 출력");
		System.out.println(">> 3. 연락처 검색");
		System.out.println(">> 4. 연락처 삭제");
		System.out.println(">> 5. 연락처 수정");
		System.out.println(">> 6. 프로그램 종료");
		System.out.println("---------------------------------");	
	}//메뉴출력메소드 끝
}
