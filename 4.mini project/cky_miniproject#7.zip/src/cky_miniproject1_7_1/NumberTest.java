package cky_miniproject1_7_1;
import java.util.*;
public class NumberTest {
	static Scanner in = new Scanner(System.in);
	
	public static void main(String[] args){
		try {
			System.out.println("태어난 연도를 입력해 주세요");
			birth();			
		}catch(InputException e) {
			System.out.println(e.getMessage());
		}
		in.close();
	}

	public static void birth()throws InputException{		
		int birth;
		if(in.hasNextInt()) {
			birth=in.nextInt();
			System.out.println(birth+"년 입니다.");
		}else {
			throw new InputException("잘못된 입력입니다.");			
		}
	}	
}
