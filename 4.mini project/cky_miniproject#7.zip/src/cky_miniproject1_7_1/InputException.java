package cky_miniproject1_7_1;

public class InputException extends Exception{
	InputException(){}
	InputException(String message){
		super(message);
	}
}
