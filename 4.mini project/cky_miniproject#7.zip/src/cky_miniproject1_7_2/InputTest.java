package cky_miniproject1_7_2;
import java.util.*;
public class InputTest {

	public static void main(String[] args) {
		Scanner in = new Scanner(System.in);
		try {
			System.out.println("사용자 아이디를 입력해주세요");
			userInput(in.nextLine());
		}catch(InputException e) {
			System.out.println(e.getMessage());
		}
		in.close();
	}
	public static void userInput(String id)throws InputException {
		char[] idChar=id.toCharArray();
		boolean idCheck = false;
		if(idChar[0]==0 || idChar[0]==32) {
			System.out.println("입력값이 존재하지 않습니다(Null, empty)");
		}else {
			for(int i=1; i<idChar.length;i++) {
				if(idChar[i]<48 || (idChar[i]>57 && idChar[i]<65) || (idChar[i]>90 &&idChar[i]<97)||idChar[i]>122) {
					
					throw new InputException("잘못된 이름을 입력했습니다");
				}else {
					idCheck = true;
				}			
			}
			if(idCheck ==true) {
				System.out.println(id);
			}
		}
	}
}
