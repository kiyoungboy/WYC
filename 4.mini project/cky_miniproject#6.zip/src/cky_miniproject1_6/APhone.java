package cky_miniproject1_6;

public class APhone implements IFunction{
	@Override
	public void connectSpeed() {
		System.out.println(IFunction.CONNECT_SPEED_3G);
	}
	@Override
	public void callingFunction() {
		System.out.println(IFunction.CALLING_POSSIBLE);
	}
	@Override
	public void remoteFunction() {
		System.out.println(IFunction.REMOTE_IMPOSSIBLE);
	}
	@Override
	public void printInfo() {
		System.out.println("APhone");
		callingFunction();
		System.out.println(IFunction.CONNECT_SPEED_3G+"입니다.");
		remoteFunction();
		System.out.println("-------------------------------");
	}
}
