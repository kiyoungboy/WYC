package cky_miniproject1_6;

public class MainClass {
	public static void main(String[] args) {
		IFunction myPhone;
		myPhone = new APhone();
		myPhone.printInfo();
		myPhone = new BPhone();
		myPhone.printInfo();
		myPhone = new CPhone();
		myPhone.printInfo();
	}
}
