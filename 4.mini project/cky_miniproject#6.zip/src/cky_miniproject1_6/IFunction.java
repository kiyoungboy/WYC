package cky_miniproject1_6;

public interface IFunction {
	String CONNECT_SPEED_3G = "불가능합니다.3G";
	String CONNECT_SPEED_4G = "가능합니다.4G";
	String CONNECT_SPEED_5G = "가능합니다.5G";
	String CALLING_POSSIBLE = "전화 가능합니다";
	String CALLING_IMPOSSIBLE = "전화 불가능합니다";
	String REMOTE_POSSIBLE = "탑재 되어 있습니다";
	String REMOTE_IMPOSSIBLE = "미탑재 되어 있습니다";
	
	void connectSpeed();
	void callingFunction();
	void remoteFunction();
	void printInfo();
}
