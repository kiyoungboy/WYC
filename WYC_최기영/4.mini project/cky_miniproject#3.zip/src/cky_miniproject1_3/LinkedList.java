package cky_miniproject1_3;

public class LinkedList {
	private ListNode tempNode;
	private ListNode head;
	public LinkedList() {
		this.tempNode = null;
	}
	
	public void insertMiddleNode(ListNode pre, String data) {
		ListNode newNode = new ListNode(data);
		newNode.link = pre.link;
		pre.link = newNode;
	}
	public void insertLastNode(String data) {
		ListNode newNode = new ListNode(data);
		if(this.tempNode == null) {
			this.tempNode = newNode;
			this.head = newNode;
		}
		if(this.tempNode.link == null || this.tempNode.link != newNode ) {
			this.tempNode.link = newNode;
			this.tempNode = newNode;
		}
	}

	public ListNode searchNode(String data) {
		ListNode temp = this.head;
		while(!temp.getData().equals(data))
			temp = temp.link;
		return temp;
	}
	
	public void reverseList() {
		ListNode next = head;
		ListNode current = next.link;
		ListNode pre = current.link;
		this.head = pre.link;		
		head.link = pre;
		pre.link = current;
		current.link = next;
		next.link = null;
	}
	public void deleteLastNode() {
		ListNode pre, temp;
		temp = this.head;
		pre = this.head;
		while(temp.link != null)
			temp = temp.link;
		while(pre.link != temp)
			pre = pre.link;
		temp = null;
		pre.link = null;
	}	
	
	public void printList() {
		ListNode temp = this.head;
		System.out.printf("L = (");
		while(temp != null){
			System.out.printf(temp.getData());
			temp = temp.link;
			if(temp != null) {
				System.out.printf(", ");
			}
		}
		System.out.println(")");
	}
}


