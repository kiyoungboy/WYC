package cky_miniproject1_4;

public class CompanyAddr extends Addr{
	private String companyName;
	private String departName;
	private String rank;
	
	CompanyAddr(String addrName, String addrPhoneNo, String addrMail, String addrAddr,  String addrGroup, String companyName, String departName, String rank){
		super(addrName, addrPhoneNo, addrMail, addrAddr, addrGroup);
		this.companyName = companyName;
		this.departName = departName;
		this.rank = rank;
	}

	public String getCompanyName() {
		return companyName;
	}

	public void setCompanyName(String companyName) {
		this.companyName = companyName;
	}

	public String getDepartName() {
		return departName;
	}

	public void setDepartName(String departName) {
		this.departName = departName;
	}

	public String getRank() {
		return rank;
	}

	public void setRank(String rank) {
		this.rank = rank;
	}
	@Override
	public void printInfo() {
		System.out.printf("이름 : %s\n��전화번호 : %s\n 이메일 : %s\n�주소 : %s\n 그룹 : %s\n 회사이름 : %s\n 부서이름 : %s\n 직급 : %s\n",super.getAddrName(), super.getAddrPhoneNo(), super.getAddrMail(),super.getAddrAddr(), super.getAddrGroup(), this.companyName, this.departName, this.rank);
	}	
}
