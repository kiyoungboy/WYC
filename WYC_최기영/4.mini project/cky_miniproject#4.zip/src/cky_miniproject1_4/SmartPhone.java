package cky_miniproject1_4;
import java.util.Scanner;
public class SmartPhone {
	
	Scanner in = new Scanner(System.in);
	Addr Addr = new Addr(null, null, null, null, null);
	Addr[] addrArray = new Addr[10];
	int count=0;
	String checkNo;

	SmartPhone(){
		
	}
	
	Addr inputAddrData() {	
		System.out.println("데이터를 입력해 주세요");
		System.out.print("이름 : ");
		this.Addr.setAddrName(in.nextLine());
		System.out.print("전화번호 : ");
		this.Addr.setAddrPhoneNo(in.nextLine());
		System.out.print("이메일 : ");
		this.Addr.setAddrMail(in.nextLine());
		System.out.print("주소 : ");
		this.Addr.setAddrAddr(in.nextLine());
		System.out.print("그룹(회사/거래처) : ");
		this.Addr.setAddrGroup(in.nextLine());
		if(checkNo.contentEquals("1")) {				
			System.out.print("회사이름 : ");
			String companyName = in.nextLine();
			System.out.print("부서이름 : ");
			String departName = in.nextLine();
			System.out.print("직급 : ");
			String rank = in.nextLine();	
			return new CompanyAddr(Addr.getAddrName(), Addr.getAddrPhoneNo(), Addr.getAddrMail(), Addr.getAddrAddr(), Addr.getAddrGroup(), companyName, departName, rank);
		}else {
			System.out.print("거래처이름 : ");
			String customerName = in.nextLine();
			System.out.print("품목이름 : ");
			String itemName = in.nextLine();
			System.out.print("직급 : ");
			String rank = in.nextLine();
			return new CustomerAddr(Addr.getAddrName(), Addr.getAddrPhoneNo(), Addr.getAddrMail(), Addr.getAddrAddr(), Addr.getAddrGroup(), customerName, itemName, rank);
		}
	}//입력메소드 끝
	
	void addAddr(Addr Addr) {
		printAddr(Addr);
		this.addrArray[count] =Addr;				
		System.out.println(">>>> 거래처데이터가 저장되었습니다. ("+(count+1)+")");
		this.count++;	
		
	}//저장메소드 끝
	
	void printAddr(Addr Addr) {
		System.out.println("------------------------------------");		
			Addr.printInfo();
		System.out.println("------------------------------------");
	}//출력메소드 끝
	
	void printAllAddr() {
		for(int i =0; i<this.count; i++) {	
				printAddr(addrArray[i]);
		}
	}//모두출력 메소드 끝	
	
	void searchAddr(String name) {		
		for(int i = 0; i<this.count;i++) {
			if(name.contentEquals(addrArray[i].getAddrName())) {
				printAddr(addrArray[i]);
				return;
			}			
		}
		System.out.println("잘못된 입력입니다.");
	}//검색메소드 끝
	
	void deleteAddr(String name) {		
		for(int i = 0; i<this.count;i++) {
			if(name.contentEquals(addrArray[i].getAddrName())) {
				for(int j =i; j<this.count-1;j++) {
					this.addrArray[j]=this.addrArray[j+1];
				}
				this.addrArray[this.count-1] = null;
				this.count --;
				printAllAddr();
				return;
			}	
		}
		System.out.println("잘못된 입력입니다.");				
	}//삭제메소드 끝
	
	void editAddr(String name, Addr newAddr) {		
		for(int i = 0; i<this.count;i++) {
			if(name.contentEquals(addrArray[i].getAddrName())) {
				addrArray[i] = newAddr;
				System.out.println("변경됐습니다");						
				return;
			}
		}
		System.out.println("잘못된 입력입니다.");
	}//수정메소드 끝	
}
