package cky_miniproject1_4;

public class CustomerAddr extends Addr{
	private String customerName;
	private String itemName;
	private String rank;
	
	CustomerAddr(String addrName, String addrPhoneNo, String addrMail, String addrAddr,  String addrGroup, String customerName, String itemName, String rank){
		super(addrName, addrPhoneNo, addrMail, addrAddr, addrGroup);
		this.customerName = customerName;
		this.itemName = itemName;
		this.rank = rank;
	}

	public String getcustomerName() {
		return customerName;
	}

	public void setcustomerName(String customerName) {
		this.customerName = customerName;
	}

	public String getItemName() {
		return itemName;
	}

	public void setitemName(String itemName) {
		this.itemName = itemName;
	}

	public String getRank() {
		return rank;
	}

	public void setRank(String rank) {
		this.rank = rank;
	}
	@Override
	public void printInfo() {
		System.out.printf("이름 : %s\n��전화번호 : %s\n 이메일 : %s\n�주소 : %s\n 그룹 : %s\n 거래처이름 : %s\n 품목이름 : %s\n 직급 : %s\n",super.getAddrName(), super.getAddrPhoneNo(), super.getAddrMail(),super.getAddrAddr(), super.getAddrGroup(), this.customerName, this.itemName, this.rank);
	}
}
