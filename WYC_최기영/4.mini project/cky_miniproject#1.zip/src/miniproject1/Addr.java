package miniproject1;

public class Addr {
	private String addrName;
	private String addrPhoneNo;
	private String addrMail;
	private String addrAddr;
	private String addrGroup;
	
	Addr(String addrName, String addrPhoneNo, String addrMail, String addrAddr,  String addrGroup){
		this.addrName = addrName;
		this.addrPhoneNo = addrPhoneNo;
		this.addrMail = addrMail;
		this.addrAddr = addrAddr;
		this.addrGroup = addrGroup;
	}
		
	public String getAddrName() {
		return addrName;
	}
	public void setAddrName(String addrName) {
		this.addrName = addrName;
	}
	public String getAddrPhoneNo() {
		return addrPhoneNo;
	}
	public void setAddrPhoneNo(String addrPhoneNo) {
		this.addrPhoneNo = addrPhoneNo;
	}
	public String getAddrMail() {
		return addrMail;
	}
	public void setAddrMail(String addrMail) {
		this.addrMail = addrMail;
	}
	public String getAddrAddr() {
		return addrAddr;
	}
	public void setAddrAddr(String addrAddr) {
		this.addrAddr = addrAddr;
	}
	public String getAddrGroup() {
		return addrGroup;
	}
	public void setAddrGroup(String addrGroup) {
		this.addrGroup = addrGroup;
	}
	
	public void printInfo() {
		System.out.printf("이름 : %s\n전화번호 : %s\n�메일 : %s\n�ּ주소 : %s\n�׷그룹�: %s\n",this.addrName, this.addrPhoneNo, this.addrMail,this.addrAddr, this.addrGroup);
	}

}
