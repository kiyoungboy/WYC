package cky_miniproject1_5;

public class SonataLowGrade extends Sonata{
	
	public int tax;
	SonataLowGrade(){
		super();
	}
	public void getSpec() {
		this.color = CarSpecs.COLOR_BLUE;
		this.tire = CarSpecs.TIRE_NORMAL;
		this.displacement = CarSpecs.DISPLACEMENT_SMALL;
		this.handle = CarSpecs.HANDLE_POWER;
		this.tax = this.displacement - 1000;
		
		System.out.println("*****************************************");
		System.out.printf("색상:%s\n타이어:%s\n배기량:%d\n핸들:%s\n세금:%d\n",this.color, this.tire, this.displacement, this.handle, this.tax);
		System.out.println("*****************************************");
		
	}

}
