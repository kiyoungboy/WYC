package cky_miniproject1_5;

public class Main {

	public static void main(String[] args) {
		Sonata sonata1 = new SonataHighGrade();
		sonata1.getSpec();
		Sonata sonata2 = new SonataLowGrade();
		sonata2.getSpec();

	}

}
