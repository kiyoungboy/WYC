package cky_miniproject1_5;

public abstract class Sonata extends CarSpecs{
	
	String tire;
	String color;
	String handle;
	int displacement;
	
	public abstract void getSpec();
	
}

