package cky_miniproject1_5;

public class CarSpecs {
	static final String COLOR_RED = "레드";
	static final String COLOR_BLUE = "블루";
	static final String TIRE_NORMAL = "일반타이어";
	static final String TIRE_WIDE = "광폭타이어";
	static final String HANDLE_NORMAL = "일반핸들";
	static final String HANDLE_POWER = "파워핸들";
	static final int DISPLACEMENT_SMALL = 2000;
	static final int DISPLACEMENT_LARGE = 2500;
	
}
