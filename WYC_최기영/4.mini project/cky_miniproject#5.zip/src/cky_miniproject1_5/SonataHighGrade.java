package cky_miniproject1_5;

public class SonataHighGrade extends Sonata{	
	
	public int tax;
	SonataHighGrade(){
		super();
	}
	public void getSpec() {
		this.color = CarSpecs.COLOR_RED;
		this.tire = CarSpecs.TIRE_WIDE;
		this.displacement = CarSpecs.DISPLACEMENT_LARGE;
		this.handle = CarSpecs.HANDLE_NORMAL;
		this.tax = this.displacement - 1000;
		
		System.out.println("*****************************************");
		System.out.printf("색상:%s\n타이어:%s\n배기량:%d\n핸들:%s\n세금:%d\n", this.color, this.tire, this.displacement, this.handle, this.tax);
		System.out.println("*****************************************");
		
	}
}
