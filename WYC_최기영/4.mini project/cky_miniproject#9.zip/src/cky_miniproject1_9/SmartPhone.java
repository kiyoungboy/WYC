package cky_miniproject1_9;
import java.io.*;
import java.text.SimpleDateFormat;
import java.util.*;
public class SmartPhone {
	
	Scanner in = new Scanner(System.in);
	List<Addr> addrList = new ArrayList<Addr>();
	Addr addr = new Addr();
	int count=0;

	SmartPhone(){
		
	}
	//입력메소드 시작
	Addr inputAddrData() {	
		File file = new File("C:/Addr");
		if(file.exists() == false) {
			file.mkdir();
			System.out.println("폴더가 생성되었습니다.");
			}
		System.out.println("데이터를 입력해 주세요");
			System.out.println("이름, 전화번호, 이메일, 주소, 그룹");
			addr = new Addr(in.nextLine(),in.nextLine(),in.nextLine(),in.nextLine(),in.nextLine());
			return addr;
	}
	//저장메소드 시작
	void addAddr(Addr addr) {
		this.addr = addr;
		addrList.add(addr);
		System.out.println(">>>> 데이터가 저장되었습니다. ("+(count+1)+")");
		this.count++;	
		
	}
	//출력메소드 시작
	void printAddr(Addr addr) {
		System.out.println("------------------------------------");		
			addr.printInfo();
		System.out.println("------------------------------------");
	}
	//전체출력 메소드 시작
	void printAllAddr() {
		for(int i =0; i<this.count; i++) {	
				printAddr(addrList.get(i));
		}
	}
	//검색메소드 시작
	void searchAddr(String phoneNo) {		
		for(int i = 0; i<this.count;i++) {
			if(phoneNo.contentEquals(addrList.get(i).getAddrPhoneNo())) {
				printAddr(addrList.get(i));
				return;
			}			
		}
		System.out.println("잘못된 입력입니다.");
	}
	//삭제메소드 시작
	void deleteAddr(String phoneNo) throws Exception {		
		for(int i = 0; i<count;i++) {
			if(phoneNo.contentEquals(addrList.get(i).getAddrPhoneNo())) {
				File file = new File("C:/Addr/"+addrList.get(i).getAddrName()+".txt");
				addrList.remove(i);
				if(file.exists()) {file.delete();}
				count--;
				printAllAddr();
				
				return;
			}	
		}
		System.out.println("잘못된 입력입니다.");				
	}
	//수정메소드 시작
	void editAddr(String phoneNo, Addr newAddr) throws Exception {
		newAddr = inputAddrData();
		for(int i = 0; i<this.count;i++) {
			if(phoneNo.contentEquals(addrList.get(i).getAddrPhoneNo())) {				
				File file = new File("C:/Addr/"+addrList.get(i).getAddrName()+".txt");
				if(file.exists()) {
					file.delete();
					file.createNewFile();
					FileOutputStream fos =new FileOutputStream("C:/Addr/"+addrList.get(i).getAddrName()+".txt");
					ObjectOutputStream oos = new ObjectOutputStream(fos);
					addrList.set(i, newAddr);
					oos.writeObject(addrList.get(i));
					System.out.println("변경됐습니다");
					oos.close();
					fos.close();
				}
				return;
			}
		}
		System.out.println("잘못된 입력입니다.");
	}
	//연락처 전체 리스트보기
	void printAllAddrFile() {
		File temp = new File("C:/Addr");
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd a HH:mm");
		File[] contents = temp.listFiles();
		System.out.println("날짜   시간  형태   크기     이름 ");
		System.out.println("------------------------------------");
		for(File file : contents) {
			System.out.println(sdf.format(new Date(file.lastModified())));
			if(file.isDirectory()) {
				System.out.println("\t<DIR>\t\t\t"+file.getName());
			}else {
				System.out.println("\t\t\t"+file.length()+"\t"+file.getName());
			}
			System.out.println();
		}
		
	}
	//연락처 파일 저장 시작
	void saveFile() throws Exception {
		
		for(int i =0; i<count;i++) {
			File file = new File("C:/Addr/"+addrList.get(i).getAddrName()+".txt");		
			if(file.exists() == false) {
				file.createNewFile();
				FileOutputStream fos = new FileOutputStream("C:/Addr/"+addrList.get(i).getAddrName()+".txt");
				ObjectOutputStream oos = new ObjectOutputStream(fos); 
				
				oos.writeObject(addrList.get(i));
				System.out.println((i+1)+"번째 파일이 생성되었습니다.");
				oos.flush();
				oos.close();
				fos.close();
			}
		}			
	}
	//연락처 파일 로드 시작
	void loadFile() throws Exception{
		for(int i =0; i<count;i++) {
			FileInputStream fis = new FileInputStream("C:/Addr/"+addrList.get(i).getAddrName()+".txt");
			ObjectInputStream ois = new ObjectInputStream(fis);
			
			Addr temp = (Addr)ois.readObject();
			printAddr(temp);
			
			ois.close();
			fis.close();
		}
	}
}
