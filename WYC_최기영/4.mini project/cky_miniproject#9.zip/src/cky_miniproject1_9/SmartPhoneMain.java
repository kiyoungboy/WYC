package cky_miniproject1_9;
import java.util.Scanner;
public class SmartPhoneMain {

	public static void main(String[] args) throws Exception {
		Scanner in = new Scanner(System.in);
		String phoneNo;
		SmartPhone myPhone = new SmartPhone();	
		while(true) {	
			printMenu();
			String selectMenu = in.nextLine();
			switch(selectMenu){
			case "1" : 	
				myPhone.inputAddrData();
				myPhone.addAddr(myPhone.addr);
				break;
			case "2" : 
				System.out.println("찾으실 정보의 핸드폰 번호를 입력해주세요");				 
				myPhone.searchAddr(in.nextLine());			
				break;
			case "3" : 
				System.out.println("삭제하고 싶은 연락처의 핸드폰 번호를 입력해주세요");
				phoneNo = in.nextLine();
				myPhone.deleteAddr(phoneNo);
				break;
			case "4" : 
				System.out.println("수정하고 싶은 연락처의 핸드폰 번호를 입력해주세요.");
				phoneNo = in.nextLine();
				myPhone.searchAddr(phoneNo);
				myPhone.editAddr(phoneNo, myPhone.addr);
				break;
			case "5" :
				myPhone.printAllAddrFile();
				break;
			case "6" :
				myPhone.saveFile();
				break;
			case "7" :
				myPhone.loadFile();
				break;
			case "8" : 
				in.close();
				return; 
				//리턴은 컨튜롤 << 명심.
//				System.exit(0);
			}
		}
	}//메인메소드 끝
	static void printMenu() {
		System.out.println("주소 관리 메뉴--------------------");
		System.out.println(">> 1. 연락처 등록");
		System.out.println(">> 2. 연락처 검색");
		System.out.println(">> 3. 연락처 삭제");
		System.out.println(">> 4. 연락처 수정");
		System.out.println(">> 5. 연락처 전체리스트보기");
		System.out.println(">> 6. 연락처 파일 저장");
		System.out.println(">> 7. 연락처 파일 로드");
		System.out.println(">> 8. 프로그럄 종료");
		System.out.println("---------------------------------");	
	}//메뉴출력메소드 끝
}
