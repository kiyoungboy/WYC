package hashMapAddr;
import java.util.*;
public class SmartPhone {
	
	Scanner in = new Scanner(System.in);
	Map<String,Addr> addrMap = new HashMap<String,Addr>();
	Set<Map.Entry<String, Addr>> keySet = addrMap.entrySet();
	Iterator<Map.Entry<String, Addr>> iterator;
	Map.Entry<String, Addr> entry;
	Addr addr = new Addr();
	String checkNo;
	int count = 0;
	
	SmartPhone(){
		
	}
	//입력메소드 시작
	Addr inputAddrData() {
		System.out.println("데이터를 입력해 주세요");
		if(checkNo.contentEquals("1")) {	
			System.out.println("이름, 핸드폰번호, 이메일, 주소, 회사이름, 부서이름, 직급을 차례대로 입력해주세요");
			addr = new CompanyAddr(in.nextLine(),in.nextLine(),in.nextLine(),in.nextLine(),"회사",in.nextLine(),in.nextLine(),in.nextLine());
			return addr;
		}else {
			System.out.println("이름, 핸드폰번호, 이메일, 주소, 거래처이름, 품목이름, 직급을 차례대로 입력해주세요");
			addr = new CustomerAddr(in.nextLine(),in.nextLine(),in.nextLine(),in.nextLine(),"거래처",in.nextLine(),in.nextLine(),in.nextLine());
			return addr;
		}
	}
	//저장메소드 시작
	void addAddr(Addr addr) {
		this.addr = addr;
		addrMap.put(addr.getAddrPhoneNo(), addr);
		System.out.println(">>>> 거래처데이터가 저장되었습니다. ("+(count+1)+")");
		this.count++;	
		
	}
	//출력메소드 시작
	void printAddr(Addr addr) {
		System.out.println("------------------------------------");		
			addr.printInfo();
		System.out.println("------------------------------------");
	}
	//전체출력 메소드 시작
	void printAllAddr() { 
		while(iterator.hasNext()) {
			entry = iterator.next();
			printAddr(entry.getValue());
		}
	}
	//검색메소드 시작
	void searchAddr(String phoneNo) {		
		while(iterator.hasNext()){
			entry = iterator.next();
			if(phoneNo.contentEquals(entry.getValue().getAddrPhoneNo())) {
				printAddr(addrMap.get(entry.getValue().getAddrPhoneNo()));
				return;
			}			
		}
		System.out.println("잘못된 입력입니다.");
	}
	//삭제메소드 시작
	void deleteAddr(String phoneNo) {	
		while(iterator.hasNext()){
			entry = iterator.next();
			if(phoneNo.contentEquals(entry.getValue().getAddrPhoneNo())) {
				addrMap.remove(entry.getValue().getAddrPhoneNo());
				count--;
				iterator = keySet.iterator();
				printAllAddr();
				return;
			}	
		}
		System.out.println("잘못된 입력입니다.");				
	}
	//수정메소드 시작
	void editAddr(String phoneNo) {
		while(iterator.hasNext()){
			entry = iterator.next();
			if(phoneNo.contentEquals(entry.getValue().getAddrPhoneNo())) {
				if(entry.getValue().getAddrGroup().contentEquals("회사")) {
					checkNo = "1";
				}else {
					checkNo = "2";
				}
				inputAddrData();
				addAddr(addr);
				System.out.println("변경됐습니다");						
				return;
			}
		}
		System.out.println("잘못된 입력입니다.");
	}
}
