package hashSetAddr;
import java.util.*;
public class SmartPhone {
	
	Scanner in = new Scanner(System.in);
	Set<Addr> addrSet = new HashSet<Addr>();
	Addr addr = new Addr();
	int count=0;
	String checkNo;

	SmartPhone(){
		
	}
	//입력메소드 시작
	Addr inputAddrData() {	
		System.out.println("데이터를 입력해 주세요");
		if(checkNo.contentEquals("1")) {	
			System.out.println("이름, 전화번호, 이메일, 주소, 회사이름, 부서이름, 직급을 차례대로 입력해주세요");
			addr = new CompanyAddr(in.nextLine(),in.nextLine(),in.nextLine(),in.nextLine(),"회사",in.nextLine(),in.nextLine(),in.nextLine());
			return addr;
		}else {
			System.out.println("이름, 전화번호, 이메일, 주소, 거래처이름, 품목이름, 직급을 차례대로 입력해주세요");
			addr = new CustomerAddr(in.nextLine(),in.nextLine(),in.nextLine(),in.nextLine(),"거래처",in.nextLine(),in.nextLine(),in.nextLine());
			return addr;
		}
	}
	//저장메소드 시작
	void addAddr(Addr addr) {
		this.addr = addr;
		addrSet.add(addr);
		System.out.println(">>>> 거래처데이터가 저장되었습니다. ("+(count+1)+")");
		this.count++;	
		
	}
	//출력메소드 시작
	void printAddr(Addr addr) {
			System.out.println("------------------------------------");		
			addr.printInfo();
			System.out.println("------------------------------------");
	}
	//전체출력 메소드 시작
	void printAllAddr() {
		for(Addr element : addrSet){
			System.out.println("-------------------------------------");
			System.out.println("이름 : "+element.getAddrName());
			System.out.println("핸드폰 번호 : "+element.getAddrPhoneNo());
			System.out.println("이메일주소 :"+element.getAddrMail());
			System.out.println("주소 :  "+element.getAddrAddr());
			System.out.println("그룹 : "+element.getAddrGroup());
			if(element instanceof CompanyAddr) {
				System.out.println("회사이름 : "+((CompanyAddr) element).getCompanyName());
				System.out.println("부서이름 : "+((CompanyAddr) element).getDepartName());
				System.out.println("직급 : "+((CompanyAddr) element).getRank());
				System.out.println("-------------------------------------");
			}
			if(element instanceof CustomerAddr) {
				System.out.println("거래처 이름 : "+((CustomerAddr) element).getcustomerName());
				System.out.println("품목이름 : "+((CustomerAddr) element).getItemName());
				System.out.println("직급 : " +((CustomerAddr) element).getRank());
				System.out.println("-------------------------------------");
			}
		}
	}
	//검색메소드 시작
	void searchAddr(String phoneNo) {		
		for(Addr element : addrSet) {
			if(phoneNo.contentEquals(element.getAddrPhoneNo())) {
				printAddr(element);
				return;
			}
		}
		
		System.out.println("잘못된 입력입니다.");
	}
	//삭제메소드 시작
	void deleteAddr(String phoneNo) {
	for(Addr element : addrSet) {
		if(phoneNo.contentEquals(element.getAddrPhoneNo())) {
			addrSet.remove(element);
			count--;
			return;
		}
	}		
		System.out.println("잘못된 입력입니다.");				
	}
	//수정메소드 시작
	void editAddr(String phoneNo) {		
		for(Addr element : addrSet) {
			if(phoneNo.contentEquals(element.getAddrPhoneNo())) {
				if(element.getAddrGroup()=="회사") {
					checkNo = "1";
				}else {
					checkNo = "2";
				}
				addrSet.remove(element);
				count--;
				inputAddrData();
				addAddr(addr);
				System.out.println("변경됐습니다");						
				return;
			}
		}
		System.out.println("잘못된 입력입니다.");
	}
}
