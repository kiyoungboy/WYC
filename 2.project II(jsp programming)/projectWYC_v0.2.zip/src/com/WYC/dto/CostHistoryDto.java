package com.WYC.dto;

public class CostHistoryDto {
	
	private int costNo;
	private String costArea;
	private String costCrop;
	private int costValue;
	
	public CostHistoryDto() {
		
	}
	public CostHistoryDto(int costNo, String costArea, String costCrop, int costValue) {
		this.costNo = costNo;
		this.costArea = costArea;
		this.costCrop = costCrop;
		this.costValue = costValue;
	}
	public int getCostNo() {
		return costNo;
	}
	public void setCostNo(int costNo) {
		this.costNo = costNo;
	}
	public String getCostArea() {
		return costArea;
	}
	public void setCostArea(String costArea) {
		this.costArea = costArea;
	}
	public String getCostCrop() {
		return costCrop;
	}
	public void setCostCrop(String costCrop) {
		this.costCrop = costCrop;
	}
	public int getCostValue() {
		return costValue;
	}
	public void setCostValue(int costValue) {
		this.costValue = costValue;
	}
	
}
