package com.WYC.dto;

public class RevenueHistoryDto {
	private int revenueNo;
	private String revenueArea;
	private String revenueCrop;
	private int revenueValue;
	
	public RevenueHistoryDto() {
		
	}
	public RevenueHistoryDto(int revenueNo, String revenueArea, String revenueCrop, int revenueValue) {
		this.revenueNo = revenueNo;
		this.revenueArea = revenueArea;
		this.revenueCrop = revenueCrop;
		this.revenueValue = revenueValue;
	}
	public int getRevenueNo() {
		return revenueNo;
	}
	public void setRevenueNo(int revenueNo) {
		this.revenueNo = revenueNo;
	}
	public String getRevenueArea() {
		return revenueArea;
	}
	public void setRevenueArea(String revenueArea) {
		this.revenueArea = revenueArea;
	}
	public String getRevenueCrop() {
		return revenueCrop;
	}
	public void setRevenueCrop(String revenueCrop) {
		this.revenueCrop = revenueCrop;
	}
	public int getRevenueValue() {
		return revenueValue;
	}
	public void setRevenueValue(int revenueValue) {
		this.revenueValue = revenueValue;
	}
	
}
