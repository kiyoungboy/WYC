package com.WYC.controller;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.WYC.command.Command;
import com.WYC.costCommand.CostCondition;
import com.WYC.costCommand.CropProductionCost;
import com.WYC.costCommand.PolicyConditionList;
import com.WYC.costCommand.PolicyList;
import com.WYC.costCommand.PolicySubsidy;
import com.WYC.profitCommand.AddProfitCondition;
import com.WYC.profitCommand.MyProfit;
import com.WYC.recommendCommand.AreaCondition;
import com.WYC.recommendCommand.Recommend;
import com.WYC.revenueCommand.FarmAreaCropListCommand;
import com.WYC.revenueCommand.FarmCheckCost;
import com.WYC.revenueCommand.FarmCropAreaCommand;
import com.WYC.revenueCommand.FarmCropHpriceYieldCommand;
import com.WYC.revenueCommand.FarmCropListCommand;
import com.WYC.revenueCommand.FarmCropProfile;
import com.WYC.revenueCommand.FarmSalesText;

/**
 * Servlet implementation class FrontController
 */
@WebServlet("*.do")
public class FrontController extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public FrontController() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		System.out.println("doGet");
		actionDo(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		System.out.println("doPost");
		actionDo(request, response);
	}
	//actionDo 시작
	private void actionDo(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		System.out.println("actionDo");
		
		request.setCharacterEncoding("UTF-8");
		
		String viewPage = null;
		Command command = null;
		
		String uri = request.getRequestURI();
		String conPath = request.getContextPath();
		String com = uri.substring(conPath.length());
		
		//추천작물 고르기
		if(com.equals("/recommend.do")) {
			String areaData = request.getParameter("areaData"); 
			String conditionData = request.getParameter("conditionData");
			request.setAttribute("areaData", areaData);
			request.setAttribute("conditionData", conditionData);
			command = new Recommend();
			command.execute(request, response);
			response.setContentType("text/plain; charset=utf-8");
			response.getWriter().println(request.getAttribute("finalResultDto"));
			return;
//			viewPage="recommend.jsp";
		//지역 추천작물 리스트
		}else if(com.equals("/AreaCondition.do")) {
			String selectedArea = request.getParameter("selectedArea");
			request.setAttribute("selectedArea", selectedArea);
			command =new AreaCondition();
			command.execute(request, response);
			response.setContentType("text/plain; charset=utf-8");
			response.getWriter().println(request.getAttribute("showRevenue1"));
			response.getWriter().println(request.getAttribute("showPcost1"));
			response.getWriter().println(request.getAttribute("showYield1"));
			response.getWriter().println(request.getAttribute("cropName1"));
			response.getWriter().println(request.getAttribute("showRevenue2"));
			response.getWriter().println(request.getAttribute("showPcost2"));
			response.getWriter().println(request.getAttribute("showYield2"));
			response.getWriter().println(request.getAttribute("cropName2"));
			response.getWriter().println(request.getAttribute("showRevenue3"));
			response.getWriter().println(request.getAttribute("showPcost3"));
			response.getWriter().println(request.getAttribute("showYield3"));
			response.getWriter().println(request.getAttribute("cropName3"));
			
			response.getWriter().println(request.getAttribute("changeRateR1"));
			response.getWriter().println(request.getAttribute("changeRateR2"));
			response.getWriter().println(request.getAttribute("changeRateR3"));
			response.getWriter().println(request.getAttribute("changeRateC1"));
			response.getWriter().println(request.getAttribute("changeRateC2"));
			response.getWriter().println(request.getAttribute("changeRateC3"));
			response.getWriter().println(request.getAttribute("changeRateY1"));
			response.getWriter().println(request.getAttribute("changeRateY2"));
			response.getWriter().println(request.getAttribute("changeRateY3"));
			
			return;
			
//			viewPage="/recommend.do";
		//비용조회 화면
		}else if(com.equals("/policyList.do")) {
			command = new PolicyList();
			System.out.println("1");
			command.execute(request, response);
			System.out.println("2");
			viewPage="serviceCost.jsp";
		//조건 입력
		}else if(com.equals("/costCondition.do")) {
			String cropName = request.getParameter("crop_policy_checkbox");
			String siGunGuName = request.getParameter("select_area_radio_2");	
			String getAge = request.getParameter("select_age_radio");
			String getFarmingPeriod = request.getParameter("select_live_radio");


			if( cropName == null ||  siGunGuName ==null || getAge == null || getFarmingPeriod == null) {
				HttpSession session = request.getSession();
				session.setAttribute("warningMessage", "조건을 모두 입력해 주세요!!!");
				response.sendRedirect("serviceCost.jsp");

				return;
			}
			command = new CostCondition();
			command.execute(request, response);
			viewPage="/cropProductCost.do";
		//농작물 비용
		}else if(com.equals("/cropProductCost.do")) {
			command = new CropProductionCost();
			command.execute(request, response);
			viewPage="/policyCondtionList.do";
		//조건부여한 리스트 조회
		}else if(com.equals("/policyCondtionList.do")) {
			command = new PolicyConditionList();
			command.execute(request, response);
			viewPage="serviceCost.jsp";
		//정책 지원금 합산
		}else if(com.equals("/policySubsidy.do")) {
			String[] selectedSubsidy = request.getParameterValues("selectedSubsidy");
			if(selectedSubsidy == null) {
				selectedSubsidy = new String[] {"0"};
			}
			command = new PolicySubsidy();
			command.execute(request, response);
			viewPage="/policyList.do";
		//수익창 불러오기
		}else if(com.equals("/myProfit.do")) {
			command = new MyProfit();
			command.execute(request, response);
			viewPage="serviceProfit.jsp";
		//수익 계산
		}else if(com.equals("/revenue1.do")) {
			command = new FarmCropListCommand();
			command.execute(request, response);
			viewPage = "revenue1.jsp";
		}else if(com.equals("/cropArea.do")) {
			String selectedCrop = request.getParameter("crop");
			request.setAttribute("crop", selectedCrop);
			System.out.println("crop_eng : "+selectedCrop);
			command = new FarmCropAreaCommand();
			command.execute(request, response);
			response.setContentType("text/plain; charset=utf-8");
			response.getWriter().println(request.getAttribute("cropAreaList"));
//			viewPage = "revenue1.jsp";
			return;
		}else if(com.equals("/salesText.do")) {
			String selectedCrop = request.getParameter("selectCrop");
			String selectedArea = request.getParameter("selectArea");
			request.setAttribute("selectCrop", selectedCrop);
			request.setAttribute("selectArea", selectedArea);
			System.out.println("crop_eng : "+selectedCrop);
			System.out.println("area_eng : "+selectedArea.trim());
			
			command = new FarmSalesText();
			command.execute(request, response);
			response.setContentType("text/plain; charset=utf-8");
			response.getWriter().println(request.getAttribute("revenues"));
			return;
		}else if(com.equals("/checkCost.do")) {
			command = new FarmCheckCost();
			command.execute(request, response);
			viewPage = "/policyList.do";
		}else if(com.equals("/revenue2.do")) {
			viewPage = "revenue2.jsp";
		}else if(com.equals("/getAreaCropList.do")) {
			String areaCrop = request.getParameter("areaCrop");
			System.out.println(areaCrop);
			request.setAttribute("areaCrop", areaCrop);
			
			command = new FarmAreaCropListCommand();
			command.execute(request, response);
			
			response.setContentType("text/plain; charset=utf-8");
			response.getWriter().println(request.getAttribute("areaCropList"));
			return;
		}else if(com.equals("/getCropProfile.do")) {
			String selectCrop = request.getParameter("selectCrop");
			System.out.println("getCropProfile.do : " + selectCrop);
			request.setAttribute("selectCrop", selectCrop);
			
			command = new FarmCropProfile();
			command.execute(request, response);
			
			response.setContentType("text/plain; charset=utf-8");
			response.getWriter().println(request.getAttribute("cropProfileList"));
			return;
		}else if(com.equals("/getCropHpriceYield.do")) {
			String selectCrop = request.getParameter("selectCrop");
			System.out.println("getCropHpriceYield.do : " + selectCrop);
			request.setAttribute("selectCrop", selectCrop);
			
			command = new FarmCropHpriceYieldCommand();
			command.execute(request, response);
			
			response.setContentType("text/plain; charset=utf-8");
			response.getWriter().println(request.getAttribute("cropHpriceYieldArrayList"));
			return;
		}
		
		RequestDispatcher dispatcher = request.getRequestDispatcher(viewPage);
		dispatcher.forward(request, response);
	}

}
