package com.WYC.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.sql.DataSource;

import com.WYC.dto.CropDto;
import com.WYC.dto.RecommendDto;
import com.WYC.dto.RecommendInfoDto;

public class RecommendDao {
	
	DataSource dataSource;
	
	public RecommendDao() {
		try {
			Context context = new InitialContext();
			dataSource = (DataSource) context.lookup("java:comp/env/jdbc/Oracle11g");
		}catch(Exception e) {
			e.printStackTrace();
		}
	}


	public ArrayList<Integer> findAreaCrops(String areaName) {
		// TODO Auto-generated method stub
		ArrayList<Integer> dtos = new ArrayList<Integer>();
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		
		try {
			conn = dataSource.getConnection();
			String query = "select area_crop1, area_crop2, area_crop3 from area_crops where area_name=?";
			pstmt = conn.prepareStatement(query);
			pstmt.setString(1, areaName);
			rs = pstmt.executeQuery();
			
			if(rs.next()) {
				int cropCode1 = rs.getInt("area_crop1");
				int cropCode2 = rs.getInt("area_crop2");
				int cropCode3 = rs.getInt("area_crop3");
				dtos.add(cropCode1);
				dtos.add(cropCode2);
				dtos.add(cropCode3);
			}
		}catch(Exception e) {
			System.out.println("지역 작물 오류");
			e.printStackTrace();
		}finally {
			try {
				if(rs!=null) rs.close();
				if(pstmt!=null) pstmt.close();
				if(conn!= null) conn.close();
			}catch(Exception e2) {
				e2.printStackTrace();
			}
		}
		
		return dtos;
	}

	public ArrayList<Integer> showRevenue(Integer cropCode) {
		// TODO Auto-generated method stub
		ArrayList<Integer> dtos = new ArrayList<Integer>();
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		
		try {
			conn = dataSource.getConnection();
			String query;
			if(cropCode == 120001) {
				query = "select revenue from crop_chives where year between 2017 and 2021";
			}else if(cropCode == 120002) {
				query = "select revenue from crop_cucumber where year between 2017 and 2021";
			}else if(cropCode == 120003) {
				query = "select revenue from crop_garlic where year between 2017 and 2021";
			}else if(cropCode == 120004) {
				query = "select revenue from crop_grape where year between 2017 and 2021";
			}else if(cropCode == 120005) {
				query = "select revenue from crop_greenonion where year between 2017 and 2021";
			}else if(cropCode == 120006) {
				query = "select revenue from crop_kiwi where year between 2017 and 2021";
			}else if(cropCode == 120007) {
				query = "select revenue from crop_onion where year between 2017 and 2021";
			}else if(cropCode == 120008) {
				query = "select revenue from crop_peach where year between 2017 and 2021";
			}else if(cropCode == 120009) {
				query = "select revenue from crop_pepper where year between 2017 and 2021";
			}else if(cropCode == 120010) {
				query = "select revenue from crop_rice where year between 2017 and 2021";
			}else if(cropCode == 120011) {
				query = "select revenue from crop_spinach where year between 2017 and 2021";
			}else if(cropCode == 120012) {
				query = "select revenue from crop_spotato where year between 2017 and 2021";
			}else if(cropCode == 120013) {
				query = "select revenue from crop_stberry where year between 2017 and 2021";
			}else{
				query = "select revenue from crop_tomato where year between 2017 and 2021";
			}	
			pstmt = conn.prepareStatement(query);
			rs = pstmt.executeQuery();
			
			while(rs.next()) {
				int revenue = rs.getInt("revenue");
				
				dtos.add(revenue);
			}
		}catch(Exception e) {
			System.out.println("추천 지역조건 dao 오류");
			e.printStackTrace();
		}finally {
			try {
				if(rs != null) rs.close();
				if(pstmt != null) pstmt.close();
				if(conn != null) conn.close();
			}catch(Exception e2) {
				e2.printStackTrace();
			}
		}
		
		return dtos;
	}

	public ArrayList<Integer> showPcost(Integer cropCode) {
		// TODO Auto-generated method stub
				ArrayList<Integer> dtos = new ArrayList<Integer>();
				Connection conn = null;
				PreparedStatement pstmt = null;
				ResultSet rs = null;
				
				try {
					conn = dataSource.getConnection();
					String query;
					if(cropCode == 120001) {
						query = "select pcost from crop_chives where year between 2017 and 2021";
					}else if(cropCode == 120002) {
						query = "select pcost from crop_cucumber where year between 2017 and 2021";
					}else if(cropCode == 120003) {
						query = "select pcost from crop_garlic where year between 2017 and 2021";
					}else if(cropCode == 120004) {
						query = "select pcost from crop_grape where year between 2017 and 2021";
					}else if(cropCode == 120005) {
						query = "select pcost from crop_greenonion where year between 2017 and 2021";
					}else if(cropCode == 120006) {
						query = "select pcost from crop_kiwi where year between 2017 and 2021";
					}else if(cropCode == 120007) {
						query = "select pcost from crop_onion where year between 2017 and 2021";
					}else if(cropCode == 120008) {
						query = "select pcost from crop_peach where year between 2017 and 2021";
					}else if(cropCode == 120009) {
						query = "select pcost from crop_pepper where year between 2017 and 2021";
					}else if(cropCode == 120010) {
						query = "select pcost from crop_rice where year between 2017 and 2021";
					}else if(cropCode == 120011) {
						query = "select pcost from crop_spinach where year between 2017 and 2021";
					}else if(cropCode == 120012) {
						query = "select pcost from crop_spotato where year between 2017 and 2021";
					}else if(cropCode == 120013) {
						query = "select pcost from crop_stberry where year between 2017 and 2021";
					}else{
						query = "select pcost from crop_tomato where year between 2017 and 2021";
					}	
					pstmt = conn.prepareStatement(query);
					rs = pstmt.executeQuery();
					
					while(rs.next()) {
						int pcost = rs.getInt("pcost");
						
						dtos.add(pcost);
					}
				}catch(Exception e) {
					System.out.println("추천 지역조건 dao 오류");
					e.printStackTrace();
				}finally {
					try {
						if(rs != null) rs.close();
						if(pstmt != null) pstmt.close();
						if(conn != null) conn.close();
					}catch(Exception e2) {
						e2.printStackTrace();
					}
				}
				
				return dtos;
	}

	public ArrayList<Integer> showYield(Integer cropCode) {
		// TODO Auto-generated method stub
		ArrayList<Integer> dtos = new ArrayList<Integer>();
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		
		try {
			conn = dataSource.getConnection();
			String query;
			if(cropCode == 120001) {
				query = "select yield from crop_chives where year between 2017 and 2021";
			}else if(cropCode == 120002) {
				query = "select yield from crop_cucumber where year between 2017 and 2021";
			}else if(cropCode == 120003) {
				query = "select yield from crop_garlic where year between 2017 and 2021";
			}else if(cropCode == 120004) {
				query = "select yield from crop_grape where year between 2017 and 2021";
			}else if(cropCode == 120005) {
				query = "select yield from crop_greenonion where year between 2017 and 2021";
			}else if(cropCode == 120006) {
				query = "select yield from crop_kiwi where year between 2017 and 2021";
			}else if(cropCode == 120007) {
				query = "select yield from crop_onion where year between 2017 and 2021";
			}else if(cropCode == 120008) {
				query = "select yield from crop_peach where year between 2017 and 2021";
			}else if(cropCode == 120009) {
				query = "select yield from crop_pepper where year between 2017 and 2021";
			}else if(cropCode == 120010) {
				query = "select yield from crop_rice where year between 2017 and 2021";
			}else if(cropCode == 120011) {
				query = "select yield from crop_spinach where year between 2017 and 2021";
			}else if(cropCode == 120012) {
				query = "select yield from crop_spotato where year between 2017 and 2021";
			}else if(cropCode == 120013) {
				query = "select yield from crop_stberry where year between 2017 and 2021";
			}else{
				query = "select yield from crop_tomato where year between 2017 and 2021";
			}	
			pstmt = conn.prepareStatement(query);
			rs = pstmt.executeQuery();
			
			while(rs.next()) {
				int yield = rs.getInt("yield");
				
				dtos.add(yield);
			}
		}catch(Exception e) {
			System.out.println("추천 지역조건 dao 오류");
			e.printStackTrace();
		}finally {
			try {
				if(rs != null) rs.close();
				if(pstmt != null) pstmt.close();
				if(conn != null) conn.close();
			}catch(Exception e2) {
				e2.printStackTrace();
			}
		}
		
		return dtos;
	}

	public String showCrop(Integer cropCode) {
		// TODO Auto-generated method stub
		String cropName = null;
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		
		try {
			conn = dataSource.getConnection();
			String query = "select crop_name from crop_code where crop_code=?";
			pstmt = conn.prepareStatement(query);
			pstmt.setInt(1, cropCode);
			rs = pstmt.executeQuery();
			
			if(rs.next()) {
				cropName = rs.getString("crop_name");
			}
		}catch(Exception e) {
			System.out.println("이름찾기 오류");
			e.printStackTrace();
		}finally {
			try {
				if(rs != null) rs.close();
				if(pstmt != null) pstmt.close();
				if(conn != null) conn.close();
			}catch(Exception e2) {
				e2.printStackTrace();
			}
		}
		
		return cropName;
	}


	public CropDto searchCrop2(int searchCode) {
		// TODO Auto-generated method stub
		CropDto dto = new CropDto();
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		
		try {
			conn = dataSource.getConnection();
			String query = "select crop_code, crop_name from crop_code where crop_code=?";
			pstmt = conn.prepareStatement(query);
			pstmt.setInt(1, searchCode);
			rs = pstmt.executeQuery();
			
			if(rs.next()) {
				int cropCode = rs.getInt("crop_code");
				String cropName = rs.getString("crop_name");
				
				dto = new CropDto(cropCode, cropName);
			}
		}catch(Exception e) {
			System.out.println("searchCrop");
		}finally {
			try {
				if(rs != null) rs.close();
				if(pstmt != null) pstmt.close();
				if(conn != null) conn.close();
			}catch(Exception e2) {
				e2.printStackTrace();
			}
		}
		
		return dto;
	}


	public RecommendDto getRecommendPoint(int selectedCrop, String commaRemoveData) {
		// TODO Auto-generated method stub
		RecommendDto dto = null;
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		
		try {
			conn = dataSource.getConnection();
			String query="select crop_code, crop_name, "+commaRemoveData+"_point from recommend_point where crop_code = ?";
			pstmt = conn.prepareStatement(query);
			pstmt.setInt(1, selectedCrop);
			rs = pstmt.executeQuery();
			
			if(rs.next()) {
				int cropCode = rs.getInt("crop_code");
				String cropName = rs.getString("crop_name");
				int recommendPoint = rs.getInt(commaRemoveData+"_point");
				dto = new RecommendDto(cropCode, cropName, recommendPoint);
			}
		}catch(Exception e) {
			e.printStackTrace();
		}finally {
			try {
				if(rs!=null) rs.close();
				if(pstmt!=null) pstmt.close();
				if(conn!=null) conn.close();
			}catch(Exception e2) {
				e2.printStackTrace();
			}
		}
		return dto;
	}


	public RecommendInfoDto searchRecommendInfo(int cropCode) {
		// TODO Auto-generated method stub
		RecommendInfoDto dto = new RecommendInfoDto();
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		
		try {
			conn = dataSource.getConnection();
			String query = "select crop_code, crop_name, revenue, pcost, work_time from recommend_info where crop_code=?";
			pstmt = conn.prepareStatement(query);
			pstmt.setInt(1, cropCode);
			rs = pstmt.executeQuery();
			
			if(rs.next()) {
				int crop_code = rs.getInt("crop_code");
				String crop_name = rs.getString("crop_name");
				int crop_revenue = rs.getInt("revenue");
				int crop_pcost = rs.getInt("pcost");
				int crop_work_time = rs.getInt("work_time");
				
				dto = new RecommendInfoDto(crop_code, crop_name, crop_revenue, crop_pcost, crop_work_time);
			}
		}catch(Exception e) {
			e.printStackTrace();
		}finally {
			try {
				if(rs!=null) rs.close();
				if(pstmt!=null) pstmt.close();
				if(conn!=null) conn.close();
			}catch(Exception e2) {
				e2.printStackTrace();
			}
		}
		
		return dto;
	}


}
