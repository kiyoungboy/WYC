package com.WYC.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.sql.DataSource;

import com.WYC.dto.CostHistoryDto;
import com.WYC.dto.RevenueHistoryDto;

public class ProfitDao {
	
	DataSource dataSource;
	
	public ProfitDao() {
		
		try {
			Context context = new InitialContext();
			dataSource = (DataSource) context.lookup("java:comp/env/jdbc/Oracle11g");
		}catch(Exception e) {
			e.printStackTrace();
		}
	}

	public ArrayList<RevenueHistoryDto> showRevenueList() {
		// TODO Auto-generated method stub
		ArrayList<RevenueHistoryDto> rDtos = new ArrayList<RevenueHistoryDto>();
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		
		try {
			conn = dataSource.getConnection();
			String query = "select revenue_no, revenue_area, revenue_crop, revenue_value from history_revenue order by revenue_no desc";
			pstmt = conn.prepareStatement(query);
			rs = pstmt.executeQuery();
			
			while(rs.next()) {
				int revenueNo = rs.getInt("revenue_no");
				String revenueArea = rs.getString("revenue_area");
				String revenueCrop = rs.getString("revenue_crop");
				int revenueValue = rs.getInt("revenue_value");
				
				RevenueHistoryDto rDto = new RevenueHistoryDto(revenueNo, revenueArea, revenueCrop, revenueValue);
				rDtos.add(rDto);
			}
		}catch(Exception e) {
			System.out.println("리베뉴 히스토리 오류");
			e.printStackTrace();
		}finally {
			try {
				if(rs != null) rs.close();
				if(pstmt != null) pstmt.close();
				if(conn != null) conn.close();
			}catch(Exception e2) {
				e2.printStackTrace();
			}
		}
		
		return rDtos;
	}

	public ArrayList<CostHistoryDto> showCostList() {
		// TODO Auto-generated method stub
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		ArrayList<CostHistoryDto> cDtos = new ArrayList<CostHistoryDto>();
		
		try {
			conn = dataSource.getConnection();
			String query = "select cost_no, cost_area, cost_crop, cost_value from history_cost order by cost_No desc";
			pstmt = conn.prepareStatement(query);
			rs = pstmt.executeQuery();
			
			while(rs.next()) {
				int costNo = rs.getInt("cost_no");
				String costArea = rs.getString("cost_area");
				String costCrop = rs.getString("cost_crop");
				int costValue = rs.getInt("cost_value");
				
				CostHistoryDto cDto = new CostHistoryDto(costNo, costArea, costCrop, costValue);
				cDtos.add(cDto);
			}
		}catch(Exception e) {
			System.out.println("비용히스토리 에러");
			e.printStackTrace();
		}finally {
			try {
				if(rs != null) rs.close();
				if(pstmt != null) pstmt.close();
				if(conn != null) conn.close();
			}catch(Exception e2) {
				e2.printStackTrace();
			}
		}
		
		return cDtos;
	}


}
