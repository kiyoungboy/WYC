package com.WYC.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.sql.DataSource;

import com.WYC.dto.AreaSiDoDto;
import com.WYC.dto.AreaSiGunGuDto;
import com.WYC.dto.CropCostDto;
import com.WYC.dto.CropDto;
import com.WYC.dto.PolicyDto;

public class CostDao {
	
	DataSource dataSource;
	
	public CostDao() {
		
		try {
			Context context = new InitialContext();
			dataSource = (DataSource) context.lookup("java:comp/env/jdbc/Oracle11g");
		}catch(Exception e) {
			e.printStackTrace();
		}
	}
	
	public CropDto searchCrop(String searchName) {	
		
		CropDto dto = new CropDto();
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		
		try {
			conn = dataSource.getConnection();
			String query = "select crop_code, crop_name from crop_code where crop_name=?";
			pstmt = conn.prepareStatement(query);
			pstmt.setString(1, searchName);
			rs = pstmt.executeQuery();
			
			if(rs.next()) {
				int cropCode = rs.getInt("crop_code");
				String cropName = rs.getString("crop_name");
				
				dto = new CropDto(cropCode, cropName);
			}
		}catch(Exception e) {
			System.out.println("searchCrop");
		}finally {
			try {
				if(rs != null) rs.close();
				if(pstmt != null) pstmt.close();
				if(conn != null) conn.close();
			}catch(Exception e2) {
				e2.printStackTrace();
			}
		}
		return dto;
	}
	
	public AreaSiDoDto searchSiDo(String searchSiDo) {
		
		AreaSiDoDto dto = new AreaSiDoDto();
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		
		try {
			conn = dataSource.getConnection();
			String query = "select k_area_code, k_area_name from k_area where k_area_name=?";
			pstmt = conn.prepareStatement(query);
			pstmt.setString(1, searchSiDo);
			rs = pstmt.executeQuery();
			
			if(rs.next()) {
				int kAreaCode = rs.getInt("k_area_code");
				String kAreaName = rs.getString("k_area_name");
				
				dto = new AreaSiDoDto(kAreaCode, kAreaName);
			}
		}catch(Exception e) {
			System.out.println("serachSiDo 오류");
			e.printStackTrace();
		}finally {
			try {
				if(rs != null) rs.close();
				if(pstmt != null) pstmt.close();
				if(conn != null) conn.close();
			}catch(Exception e2) {
				e2.printStackTrace();
			}
		}
		return dto;
	}

	public AreaSiGunGuDto searchSiGunGu(String searchSiGunGu) {
		// TODO Auto-generated method stub
		AreaSiGunGuDto dto = new AreaSiGunGuDto();
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		
		try {
			conn = dataSource.getConnection();
			String query = "select area_code , area_name from area_code where area_name=?";
			pstmt = conn.prepareStatement(query);
			pstmt.setString(1, searchSiGunGu);
			rs = pstmt.executeQuery();
			
			if(rs.next()) {
				int areaCode = rs.getInt("area_code");
				String areaName = rs.getString("area_name");
				
				dto = new AreaSiGunGuDto(areaCode, areaName);
			}
		}catch(Exception e) {
			System.out.println("searchSiGunGu 오류");
			e.printStackTrace();
		}finally {
			try {
				if(rs != null) rs.close();
				if(pstmt != null) pstmt.close();
				if(conn != null) conn.close();
			}catch(Exception e2) {
				e2.printStackTrace();
			}
		}
		
		return dto;
	}

	public CropCostDto searchCost(int searchCost) {
		// TODO Auto-generated method stub
		
		CropCostDto dto = new CropCostDto();
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		
		try{
			conn = dataSource.getConnection();
			String query;
			if(searchCost == 120001) {
				query = "select Pcost, crop_code from crop_chives where crop_code = ? and year=?";
			}else if(searchCost ==120002) {
				query = "select Pcost, crop_code from crop_cucumber where crop_code = ? and year=?";
			}else if(searchCost ==120003) {
				query = "select Pcost, crop_code from crop_garlic where crop_code = ? and year=?";
			}else if(searchCost ==120004) {
				query = "select Pcost, crop_code from crop_grape where crop_code = ? and year=?";
			}else if(searchCost ==120005) {
				query = "select Pcost, crop_code from crop_greenonion where crop_code = ? and year=?";
			}else if(searchCost ==120006) {
				query = "select Pcost, crop_code from crop_kiwi where crop_code = ? and year=?";
			}else if(searchCost ==120007) {
				query = "select Pcost, crop_code from crop_onion where crop_code = ? and year=?";
			}else if(searchCost ==120008) {
				query = "select Pcost, crop_code from crop_peach where crop_code = ? and year=?";
			}else if(searchCost ==120009) {
				query = "select Pcost, crop_code from crop_pepper where crop_code = ? and year=?";
			}else if(searchCost ==120010) {
				query = "select Pcost, crop_code from crop_rice where crop_code = ? and year=?";
			}else if(searchCost ==120011) {
				query = "select Pcost, crop_code from crop_spinach where crop_code = ? and year=?";
			}else if(searchCost ==120012) {
				query = "select Pcost, crop_code from crop_spotato where crop_code = ? and year=?";
			}else if(searchCost ==120013) {
				query = "select Pcost, crop_code from crop_stberry where crop_code = ? and year=?";
			}else {
				query = "select Pcost, crop_code from crop_tomato where crop_code = ? and year=?";
			}
			pstmt = conn.prepareStatement(query);
			pstmt.setInt(1, searchCost);
			pstmt.setInt(2, 2021);
			rs = pstmt.executeQuery();
			
			if(rs.next()) {
				int cropCode = rs.getInt("crop_code");
				int cropCost = rs.getInt("Pcost");
				
				dto = new CropCostDto(cropCode, cropCost);
			}
		}catch(Exception e) {
			System.out.println("searchCost 오류");
			e.printStackTrace();
		}finally {
			try {
				if(rs != null) rs.close();
				if(pstmt != null) pstmt.close();
				if(conn != null) conn.close();
			}catch(Exception e2) {
				e2.printStackTrace();
			}
		}
		
		return dto;
	}

	public ArrayList<PolicyDto> showConditionList( int siGunGuCode, int age, int farmingPeriod) {
		// TODO Auto-generated method stub
		
		ArrayList<PolicyDto> dtos = new ArrayList<PolicyDto>();
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		System.out.println("예");
		try {
			conn = dataSource.getConnection();
			String query;
			if(  siGunGuCode != 0 && age != 0) {
				query = "select policy_name, area_name, fcost, pcost, area_code, age_up, age_down, residence_period, description from cost_policy where area_code = ? and  ? between age_up and age_down and residence_period = ? order by area_code desc";
				pstmt = conn.prepareStatement(query);
				pstmt.setInt(1, siGunGuCode);
				pstmt.setInt(2, age);
				pstmt.setInt(3, farmingPeriod);
				System.out.println("예2");
			}else {
				query = "select area_code, area_name,policy_name,  age_up, age_down, residence_period, pcost, fcost, description from cost_policy order by area_code desc";
				pstmt = conn.prepareStatement(query);
			}
			
			rs = pstmt.executeQuery();
			
			while(rs.next()) {
				String policyName = rs.getString("policy_name");
				int Fcost = rs.getInt("fcost");
				int Pcost = rs.getInt("pcost");
				String areaName = rs.getString("area_name");
				int areaCode = rs.getInt("area_code");
				int ageUp = rs.getInt("age_up");
				int ageDown = rs.getInt("age_down");
				int residencePeriod = rs.getInt("residence_period");
				String description = rs.getString("description");
				
				PolicyDto dto = new PolicyDto(areaCode, areaName, policyName, ageUp, ageDown, residencePeriod, Pcost, Fcost, description);
				dtos.add(dto);
			}
		}catch(Exception e) {
			System.out.println("List에러");
			e.printStackTrace();
		}finally {
			try {
				if(rs != null) rs.close();
				if(pstmt != null) pstmt.close();
				if(conn != null) conn.close();
			}catch(Exception e2) {
				e2.printStackTrace();
			}
		}
		return dtos;
	}
	
	public ArrayList<PolicyDto> showList(){
		ArrayList<PolicyDto> dtos = new ArrayList<PolicyDto>();
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		
		try{
			conn = dataSource.getConnection();
			String query = "select area_code, area_name, policy_name,  age_up, age_down, residence_period, pcost, fcost, description from cost_policy order by area_code desc";
			pstmt = conn.prepareStatement(query);
			rs = pstmt.executeQuery();
			
			while(rs.next()) {
				String policyName = rs.getString("policy_name");
				int Fcost = rs.getInt("fcost");
				int Pcost = rs.getInt("pcost");
				String areaName = rs.getString("area_name");
				int areaCode = rs.getInt("area_code");
				int ageUp = rs.getInt("age_up");
				int ageDown = rs.getInt("age_down");
				int residencePeriod = rs.getInt("residence_period");
				String description = rs.getString("description");
				
				PolicyDto dto = new PolicyDto(areaCode, areaName, policyName, ageUp, ageDown, residencePeriod, Pcost, Fcost, description);
				dtos.add(dto);
			}
		}catch(Exception e) {
			System.out.println("그냥출력 오류");
			e.printStackTrace();
		}finally {
			try {
				if(rs != null) rs.close();
				if(pstmt != null) pstmt.close();
				if(conn != null) conn.close();
			}catch(Exception e2) {
				e2.printStackTrace();
			}
		}
		return dtos;
	}

	public PolicyDto selectSubsidy(String checkedPolicy) {
		// TODO Auto-generated method stub
		
		PolicyDto dto = new PolicyDto();
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		
		try {
			conn = dataSource.getConnection();
			String 	query = "select policy_name, area_name, fcost, pcost, area_code, age_up, age_down, resisdence_period, description from cost_policy where policy_name=?";
			pstmt = conn.prepareStatement(query);
			pstmt.setString(1, checkedPolicy);
			rs = pstmt.executeQuery();
			
			if(rs.next()) {
				String policyName = rs.getString("policy_name");
				int Fcost = rs.getInt("fcost");
				int Pcost = rs.getInt("pcost");
				String areaName = rs.getString("area_name");
				int areaCode = rs.getInt("area_code");
				int ageUp = rs.getInt("age_up");
				int ageDown = rs.getInt("age_down");
				int residencePeriod = rs.getInt("resisdence_period");
				String description = rs.getString("description");
				
				dto = new PolicyDto(areaCode, areaName, policyName, Fcost, Pcost, ageUp, ageDown, residencePeriod, description);
				
			}
		}catch(Exception e) {
			System.out.println("보조금 에러");
			e.printStackTrace();
		}finally {
			try {
				if(rs != null) rs.close();
				if(pstmt != null) pstmt.close();
				if(conn != null) conn.close();
			}catch(Exception e2) {
				e2.printStackTrace();
			}
		}
		
		return null;
	}

	public void saveCost(String costArea, String costCrop, int totalCost) {
		// TODO Auto-generated method stub
		Connection conn = null;
		PreparedStatement pstmt = null;
		
		try {
			conn = dataSource.getConnection();
			String query = "insert into history_cost (cost_no, cost_area, cost_crop, cost_value) values(cost_sequence.nextval,?,?,?)";
			pstmt = conn.prepareStatement(query);
			pstmt.setString(1, costArea);
			pstmt.setString(2, costCrop);
			pstmt.setInt(3, totalCost);
			int rs = pstmt.executeUpdate();
		}catch(Exception e) {
			e.printStackTrace();
		}finally {
			try {
				if(pstmt != null) pstmt.close();
				if(conn != null) conn.close();
			}catch(Exception e2) {
				e2.printStackTrace();
			}
		}
		
	}
	
	
}
