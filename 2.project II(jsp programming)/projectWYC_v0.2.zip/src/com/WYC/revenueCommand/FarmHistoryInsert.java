package com.WYC.revenueCommand;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.WYC.command.Command;
import com.WYC.dao.FarmDao;

public class FarmHistoryInsert implements Command{

	@Override
	public void execute(HttpServletRequest request, HttpServletResponse response) {
		System.out.println("FarmHistoryInsert 연결 성공");
		FarmDao dao = new FarmDao();
		
		String wycId = (String) request.getAttribute("wycId");
		String selectCrop = (String) request.getAttribute("selectCrop");
		String selectCropKor = (String) request.getAttribute("selectCropKor");
		String selectArea = (String) request.getAttribute("selectArea");
//		int salesResult = Integer.parseInt((String) request.getAttribute("salesResult"));
		String chageIntegerString = ((String) request.getAttribute("salesResult")).replaceAll(",", "");
		int salesResult = Integer.parseInt(chageIntegerString);
		
		System.out.println("wycId : " + wycId);
		System.out.println("selectCrop : " + selectCrop);
		System.out.println("selectCropKor : " + selectCropKor);
		System.out.println("selectArea : " + selectArea.trim());
		System.out.println("salesResult : " + salesResult);
		
		dao.historySave(wycId, selectCrop, selectArea, selectCropKor, salesResult);
		
		
	}

}
