package com.WYC.revenueCommand;

import java.util.ArrayList;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.WYC.command.Command;
import com.WYC.dao.FarmDao;

public class FarmSalesText implements Command {

	@Override
	public void execute(HttpServletRequest request, HttpServletResponse response) {
		System.out.println("FarmSalesText 연결 성공 ");
		HttpSession session = request.getSession();
		String selectCrop = (String)request.getAttribute("selectCrop");
		String selectArea = (String)request.getAttribute("selectArea");
		System.out.println("FarmSalesText(crop)" + selectCrop);
		System.out.println("FarmSalesText(area)" + selectArea);
		
		
		FarmDao dao = new FarmDao();

		ArrayList<Integer> revenues = dao.findRevenue(selectCrop);
		selectCrop = convertEnglish(selectCrop);
		int cropPredictValue = dao.findPredictRevenue(selectCrop);
		revenues.add(cropPredictValue);
		
		System.out.println("revenues : " + revenues);
		request.setAttribute("revenues", revenues);
		
		
		
	}
	
	private String convertEnglish(String selectCrop) {
		if(selectCrop.equals("chives")) {
			selectCrop = "쪽파";
		}else if(selectCrop.equals("cucumber")) {
			selectCrop = "오이";
		}else if(selectCrop.equals("garlic")) {
			selectCrop = "마늘";
		}else if(selectCrop.equals("grape")) {
			selectCrop = "포도";
		}else if(selectCrop.equals("greenonion")) {
			selectCrop = "대파";
		}else if(selectCrop.equals("kiwi")) {
			selectCrop = "참다래";
		}else if(selectCrop.equals("onion")) {
			selectCrop = "양파";
		}else if(selectCrop.equals("peach")) {
			selectCrop = "복숭아";
		}else if(selectCrop.equals("pepper")) {
			selectCrop = "고추";
		}else if(selectCrop.equals("rice")) {
			selectCrop = "정곡";
		}else if(selectCrop.equals("spinach")) {
			selectCrop = "시금치";
		}else if(selectCrop.equals("spotato")) {
			selectCrop = "고구마";
		}else if(selectCrop.equals("stberry")) {
			selectCrop = "딸기";
		}else if(selectCrop.equals("tomato")) {
			selectCrop = "토마토";
		}else {
			System.out.println("잘못된 이름입니다.");
		}
		
		return selectCrop;
	}

}
