package com.WYC.revenueCommand;

import java.util.ArrayList;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.WYC.command.Command;
import com.WYC.dao.FarmDao;
import com.WYC.dto.FarmCropDto;

public class FarmCropListCommand implements Command{

	@Override
	public void execute(HttpServletRequest request, HttpServletResponse response) {
		FarmDao dao = new FarmDao();
		ArrayList<FarmCropDto> dtos = dao.cropList();
		request.setAttribute("cropList", dtos);
	}

}
