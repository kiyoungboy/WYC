package com.WYC.revenueCommand;

import java.io.IOException;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.WYC.command.Command;

public class FarmCheckCost implements Command{

	@Override
	public void execute(HttpServletRequest request, HttpServletResponse response) throws IOException {
		// TODO Auto-generated method stub
		String getRevenue = request.getParameter("salesResult").replaceAll(",", "");
		System.out.println(getRevenue);
		int myRevenue = Integer.parseInt(getRevenue);
		
		request.setAttribute("salesResult", myRevenue);
	}

}
