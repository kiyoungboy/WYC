package com.WYC.costCommand;

import java.util.ArrayList;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.WYC.command.Command;
import com.WYC.dao.CostDao;
import com.WYC.dto.PolicyDto;

public class PolicyList implements Command{
	
	private static final int LIST_PER_PAGE = 5;

	@Override
	public void execute(HttpServletRequest request, HttpServletResponse response) {
		// TODO Auto-generated method stub
		
		CostDao dao = new CostDao();
		ArrayList<PolicyDto> dtos = dao.showList();
		
		HttpSession session = request.getSession();
		
		String selectedCropName = request.getParameter("selectCropKor");
		String selectedAreaName = request.getParameter("selectAreaKor");
		if(selectedCropName == null) {
			selectedCropName = "쪽파";
		}
		if(selectedAreaName == null) {
			selectedAreaName = "강진";
		}
		
		if(selectedAreaName.length() ==4) {
			selectedAreaName = selectedAreaName.substring(1,3);
		}
		if(selectedAreaName.length() ==3 ) {
			selectedAreaName = selectedAreaName.substring(0,2);
		}
		
		
		selectedCropName = changeToKorean(selectedCropName);
		
		System.out.println(selectedCropName);
		System.out.println(selectedAreaName);
		
		//현재 페이지 번호 불러오기
		int currentPage = 1;
		String page = request.getParameter("page");
		if(page != null) {
			currentPage = Integer.parseInt(page);
		}
		
		// 전체 데이터 수
		int totalData = dtos.size();
		
		//총 페이지수
		int totalPage = (int)Math.ceil((double)totalData / LIST_PER_PAGE);
		
		//현재 페이지에 해당하는 데이터를 선택
		ArrayList<PolicyDto> currentDatas = getDataForPage(dtos, currentPage);
		
		// JSP에 데이터 전달
		request.setAttribute("currentPage", currentPage);
		request.setAttribute("totalPage", totalPage);
		request.setAttribute("currentDatas", currentDatas);
		session.setAttribute("selectedCropName", selectedCropName);
		session.setAttribute("selectedAreaName", selectedAreaName);
	}

	private ArrayList<PolicyDto> getDataForPage(ArrayList<PolicyDto> dtos, int currentPage) {
		// TODO Auto-generated method stub
		int startIndex = (currentPage - 1) * LIST_PER_PAGE;
		int endIndex = Math.min(startIndex + LIST_PER_PAGE, dtos.size());
		return new ArrayList<>(dtos.subList(startIndex, endIndex));
	}
	
	private String changeToKorean(String selectedCrop) {
		if(selectedCrop.equals("쪽파")) {
			selectedCrop = "chives";
		}else if(selectedCrop.equals("오이")) {
			selectedCrop = "cucumber";
		}else if(selectedCrop.equals("마늘")) {
			selectedCrop = "garlic";
		}else if(selectedCrop.equals("포도")) {
			selectedCrop = "grape";
		}else if(selectedCrop.equals("대파")) {
			selectedCrop = "greenonion";
		}else if(selectedCrop.equals("참다래")) {
			selectedCrop = "kiwi";
		}else if(selectedCrop.equals("양파")) {
			selectedCrop = "onion";
		}else if(selectedCrop.equals("복숭아")) {
			selectedCrop = "peach";
		}else if(selectedCrop.equals("고추")) {
			selectedCrop = "pepper";
		}else if(selectedCrop.equals("정곡")) {
			selectedCrop = "rice";
		}else if(selectedCrop.equals("시금치")) {
			selectedCrop = "spinach";
		}else if(selectedCrop.equals( "고구마")) {
			selectedCrop = "spotato";
		}else if(selectedCrop.equals("딸기")) {
			selectedCrop = "stberry";
		}else if(selectedCrop.equals("토마토")) {
			selectedCrop = "tomato";
		}else {
			System.out.println("잘못된 이름입니다.");
		}
		
		return selectedCrop;
	}

}
