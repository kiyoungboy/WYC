package com.WYC.costCommand;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.WYC.command.Command;
import com.WYC.dao.CostDao;

public class CostHistory implements Command{

	@Override
	public void execute(HttpServletRequest request, HttpServletResponse response) {
		// TODO Auto-generated method stub
		CostDao dao = new CostDao();

		
		String costArea = request.getParameter("costArea");
		String costCrop = request.getParameter("costCrop");
		
		int totalCost = Integer.parseInt(request.getParameter("totalCost"));
		System.out.println("costArea : "+costArea);
		System.out.println("costCrop : "+costCrop);
		System.out.println("totalCost : "+totalCost);
//		String mId = request.getParameter("memberId");
		dao.saveCost(costArea, costCrop, totalCost);
	}

}
