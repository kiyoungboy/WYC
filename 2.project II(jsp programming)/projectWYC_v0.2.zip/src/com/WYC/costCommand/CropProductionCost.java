package com.WYC.costCommand;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.WYC.command.Command;
import com.WYC.dao.CostDao;
import com.WYC.dto.CropCostDto;
import com.WYC.dto.CropDto;

public class CropProductionCost implements Command{
	

	@Override
	public void execute(HttpServletRequest request, HttpServletResponse response) throws IOException {
		// TODO Auto-generated method stub
		
		HttpSession session = request.getSession();
		System.out.println("코드 : "+(int) session.getAttribute("cropCode"));
		int cropCode = (int) session.getAttribute("cropCode");
		
		
		CostDao dao = new CostDao();
		CropCostDto dto = dao.searchCost(cropCode);
		
//		cropCost = dto.getCropCost();
		int cropCost = dto.getCropCost();
		session.setAttribute("cropCost", cropCost);
		System.out.println("cropCost:"+cropCost);
	}



}
