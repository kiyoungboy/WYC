package com.WYC.costCommand;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.WYC.command.Command;
import com.WYC.dao.CostDao;
import com.WYC.dto.PolicyDto;

public class PolicyConditionList implements Command{

	private static final int LIST_PER_PAGE = 5;
	
	@Override
	public void execute(HttpServletRequest request, HttpServletResponse response) throws IOException {
		// TODO Auto-generated method stub
		
		HttpSession session = request.getSession();
		String costCrop = (String) session.getAttribute("cropName");
		
		
		int siGunGuCode = (int) session.getAttribute("siGunGuCode");
		int age = (int) session.getAttribute("age");
		int farmingPeriod = (int) session.getAttribute("farmingPeriod");
		int cropCost = (int) session.getAttribute("cropCost");
		
		int totalCost = cropCost;
		
		CostDao dao = new CostDao();
		ArrayList<PolicyDto> dtos = dao.showConditionList( siGunGuCode, age, farmingPeriod);
		
		
		
		//현재 페이지 번호 불러오기
		int currentPage =1;
		String page = request.getParameter("page");
		if(page != null) {
			currentPage = Integer.parseInt(page);
		}
		
		//전체 데이터 수
		int totalData = dtos.size();
		
		//총 페이지 수
		int totalPage = (int)Math.ceil((double)totalData / LIST_PER_PAGE);
		
		//현재 페이지에 해당하는 데이터를 선택
		ArrayList<PolicyDto> currentDatas = getDataForPage(dtos, currentPage);
		
	
		session.setAttribute("costCrop", costCrop);
		session.setAttribute("totalCost", totalCost);
		request.setAttribute("currentPage", currentPage);
		request.setAttribute("totalPage", totalPage);
		request.setAttribute("currentDatas", currentDatas);
	}

private ArrayList<PolicyDto> getDataForPage(ArrayList<PolicyDto> dtos, int currentPage) {
	// TODO Auto-generated method stub
	int startIndex = (currentPage -1) * LIST_PER_PAGE;
	int endIndex = Math.min(startIndex + LIST_PER_PAGE, dtos.size());
	return new ArrayList<>(dtos.subList(startIndex, endIndex));
}

}
