package com.WYC.costCommand;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.WYC.command.Command;
import com.WYC.dao.CostDao;
import com.WYC.dto.AreaSiDoDto;
import com.WYC.dto.AreaSiGunGuDto;
import com.WYC.dto.CropDto;

public class CostCondition implements Command{
	

	@Override
	public void execute(HttpServletRequest request, HttpServletResponse response) throws IOException {
		// TODO Auto-generated method stub
		
		String cropName = request.getParameter("crop_policy_checkbox");
		String siGunGuName = request.getParameter("select_area_radio_2");
		
		String getAge = request.getParameter("select_age_radio");
		String getFarmingPeriod = request.getParameter("select_live_radio");
		String getRevenue = request.getParameter("salesResult");
		
		HttpSession session = request.getSession();
		
		if( cropName == null  || siGunGuName ==null || getAge == null || getFarmingPeriod == null) {
			session.setAttribute("warningMessage", "조건을 모두 입력해 주세요!!!");
			
			response.sendRedirect("serviceCost.jsp");
			return;
		}
		CostDao dao = new CostDao();
		CropDto dtoCrop = dao.searchCrop(cropName);
		int cropCode = dtoCrop.getCropCode();
		System.out.println(cropCode);
		AreaSiGunGuDto dtoSiGunGu = dao.searchSiGunGu(siGunGuName);
		int siGunGuCode = dtoSiGunGu.getAreaCode();
		System.out.println("sigungu code : " + siGunGuCode);
		System.out.println("getAge : "+getAge);
		System.out.println("getFarmingPeriod:"+getFarmingPeriod);
		int age = Integer.parseInt(getAge);
		int farmingPeriod = Integer.parseInt(getFarmingPeriod);
		int myRevenue = Integer.parseInt(getRevenue);
		
		if(checkAllCondition( cropCode,   siGunGuCode,  age)) {
			
			session.setAttribute("cropCode", cropCode);
	        session.setAttribute("siGunGuCode", siGunGuCode);
	        session.setAttribute("age", age);
	        session.setAttribute("farmingPeriod", farmingPeriod);
	        session.setAttribute("salesResult", myRevenue);
		}else {
			System.out.println("조건체크에러");
		}
		
	}
	
	private boolean checkAllCondition(int cropCode, int siGunGuCode, int age) {
		if(cropCode != 0  && siGunGuCode != 0 && age != 0 ) {
			return true;
		}else {
			return false;
		}
	}


	
}
