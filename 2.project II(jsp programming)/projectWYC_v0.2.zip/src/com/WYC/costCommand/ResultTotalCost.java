package com.WYC.costCommand;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.WYC.command.Command;
import com.WYC.dao.CostDao;

public class ResultTotalCost implements Command{

	@Override
	public void execute(HttpServletRequest request, HttpServletResponse response) {
		// TODO Auto-generated method stub
		PolicySubsidy ps = new PolicySubsidy();
		ps.execute(request, response);
//		HttpSession session = request.getSession();
		
		int cropCost = Integer.parseInt(request.getParameter("cropCost"));
		
		System.out.println("cropCost : "+cropCost);

	}

}
