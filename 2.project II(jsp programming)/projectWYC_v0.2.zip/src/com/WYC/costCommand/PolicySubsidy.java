package com.WYC.costCommand;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.WYC.command.Command;
import com.WYC.dao.CostDao;
import com.WYC.dto.PolicyDto;

public class PolicySubsidy implements Command{
	
	
	@Override
	public void execute(HttpServletRequest request, HttpServletResponse response) {
		// TODO Auto-generated method stub
		int totalSubsidy = 0;
		String[] selectedSubsidy = request.getParameterValues("selectedSubsidy");
		
		if (selectedSubsidy == null) {
	        HttpSession session = request.getSession();
	        session.setAttribute("warningMessage", "정책지원금을 선택해 주세요!!!");
	        return; // Return without further processing
	    }
		
		String costArea = request.getParameter("costArea");
		String costCrop = request.getParameter("costCrop");
		String myRevenue = request.getParameter("salesResult");
		for(int i = 0; i<selectedSubsidy.length; i++) {
			totalSubsidy  += Integer.parseInt(selectedSubsidy[i]);
			System.out.println(i +" : " + selectedSubsidy[i]);
		}
		System.out.println(costCrop);
		HttpSession session = request.getSession();
		System.out.println("totalSubsidy : "+ totalSubsidy);
		session.setAttribute("totalSubsidy", totalSubsidy);
		session.setAttribute("salesResult", myRevenue);
		session.setAttribute("costArea", costArea);
		session.setAttribute("costCrop", costCrop);
		int totalCost;
		int cropCost = Integer.parseInt(request.getParameter("cropCost"));
		totalCost = cropCost - totalSubsidy;
	
		session.setAttribute("totalCost", totalCost);
		session.setAttribute("cropCost", cropCost);
	}


}
