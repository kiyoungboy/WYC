package com.WYC.profitCommand;

import java.io.IOException;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.WYC.command.Command;

public class AddProfitCondition implements Command{

	@Override
	public void execute(HttpServletRequest request, HttpServletResponse response) throws IOException {
		// TODO Auto-generated method stub
		
		HttpSession session = request.getSession();
		
		String selectedYield = request.getParameter("selectedYield");
		String selectedFarmer = request.getParameter("selectedFarmer");
		String selectedFcost = request.getParameter("selectedFcost");
		int yieldPoint=0;
		double farmerPoint=0;
		int fcostPoint=0;
		System.out.println(selectedYield);
		if(selectedYield != null) {
			if(selectedYield.equals("10a")) {
				yieldPoint = 1;
			}else if(selectedYield.equals("20a")) {
				yieldPoint = 2;
			}else if(selectedYield.equals("30a")) {
				yieldPoint = 3;
			}else if(selectedYield.equals("40a")) {
				yieldPoint = 4;
			}
			session.setAttribute("yieldPoint", yieldPoint);
		}else {
			System.out.println("경작면적 값이 존재하지 않습니다.");
		}
		
		if(selectedFarmer != null) {
			if(selectedFarmer.equals("없음")) {
				farmerPoint = 1;
			}else if(selectedFarmer.equals("1명")) {
				farmerPoint = 1.09;
			}else if(selectedFarmer.equals("2명")) {
				farmerPoint = 1.12;
			}else if(selectedFarmer.equals("3명")) {
				farmerPoint = 1.13;
			}
			session.setAttribute("farmerPoint", farmerPoint);
		}else {
			System.out.println("노동인구 값이 존재하지 않습니다.");
		}
		
		if(selectedFcost != null) {
			if(selectedFcost.equals("없음")) {
				fcostPoint = 0;
			}else if(selectedFcost.equals("5,000만원")) {
				fcostPoint = 50000000;
			}else if(selectedFcost.equals("7,500만원")) {
				fcostPoint= 75000000;
			}else if(selectedFcost.equals("1억원")) {
				fcostPoint= 100000000;
			}
			session.setAttribute("fcostPoint", fcostPoint);
		}else {
			System.out.println("추가비용 값이 존재하지않습니다");
		}
		
		
	}
	

}
