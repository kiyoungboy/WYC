package com.WYC.profitCommand;

import java.util.ArrayList;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.WYC.command.Command;
import com.WYC.dao.ProfitDao;
import com.WYC.dto.CostHistoryDto;
import com.WYC.dto.RevenueHistoryDto;

public class MyProfit implements Command{

	@Override
	public void execute(HttpServletRequest request, HttpServletResponse response) {
		// TODO Auto-generated method stub
		System.out.println("수퍼테스트");
		String getTotalCost = request.getParameter("totalCost");
		String getSalesResult = request.getParameter("salesResult");
		String getCropCost = request.getParameter("cropCost");
		String getTotalSubsidy = request.getParameter("totalSubsidy");
		String costCrop = request.getParameter("costCrop");
		System.out.println("a : "+costCrop);
		int totalCost=0;
		int salesResult=0;
		int cropCost=0;
		int totalSubsidy=0;
		
		if(getTotalCost != null) {
			totalCost = Integer.parseInt(getTotalCost);
		}
		if(getSalesResult != null && !getSalesResult.isEmpty()) {
			salesResult = Integer.parseInt(getSalesResult);
		}
		if(getCropCost != null) {
			cropCost = Integer.parseInt(getCropCost);
		}
		if(getTotalSubsidy != null && !getTotalSubsidy.isEmpty()) {
			totalSubsidy = Integer.parseInt(getTotalSubsidy);
		}
		System.out.println("totalCost : "+ totalCost);

		System.out.println("salesResult : "+ salesResult);
		System.out.println("cropCost : "+cropCost);
		
		request.setAttribute("totalCost", totalCost);
		request.setAttribute("salesResult", salesResult);
		request.setAttribute("cropCost", cropCost);
		request.setAttribute("totalSubsidy", totalSubsidy);
		
	}

}
