package com.WYC.recommendCommand;

import java.util.ArrayList;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.WYC.command.Command;
import com.WYC.dao.RecommendDao;

public class AreaCondition implements Command{

	@Override
	public void execute(HttpServletRequest request, HttpServletResponse response) {
		// TODO Auto-generated method stub
		
		String areaName = request.getParameter("selectedArea");
		RecommendDao dao = new RecommendDao();
		ArrayList<Integer> dtos = dao.findAreaCrops(areaName);
		//작물1 <- 1번테이블
		ArrayList<Integer> showRevenue1 = dao.showRevenue(dtos.get(0)); //5개
		ArrayList<Integer> showPcost1 = dao.showPcost(dtos.get(0)); //5개
		ArrayList<Integer> showYield1 = dao.showYield(dtos.get(0)); //5개
		String cropName1 = dao.showCrop(dtos.get(0));
		//작물2 <- 2번테이블
		ArrayList<Integer> showRevenue2 = dao.showRevenue(dtos.get(1));
		ArrayList<Integer> showPcost2 = dao.showPcost(dtos.get(1));
		ArrayList<Integer> showYield2 = dao.showYield(dtos.get(1));
		String cropName2= dao.showCrop(dtos.get(1));
		//작물3 <- 3번테이블
		ArrayList<Integer> showRevenue3 = dao.showRevenue(dtos.get(2));
		ArrayList<Integer> showPcost3 = dao.showPcost(dtos.get(2));
		ArrayList<Integer> showYield3 = dao.showYield(dtos.get(2));
		String cropName3 = dao.showCrop(dtos.get(2));
		
		ArrayList<Integer> profit1 = new ArrayList<Integer>();
		for(int i =0; i<showRevenue1.size(); i++) {
			int revenue = showRevenue1.get(i);
			int pcost = showPcost1.get(i);
			int profit = revenue - pcost;
			profit1.add(profit);
		}
		ArrayList<Integer> profit2 = new ArrayList<Integer>();
		for(int i =0; i<showRevenue2.size(); i++) {
			int revenue = showRevenue2.get(i);
			int pcost = showPcost2.get(i);
			int profit = revenue - pcost;
			profit2.add(profit);
		}
		ArrayList<Integer> profit3 = new ArrayList<Integer>();
		for(int i =0; i<showRevenue3.size(); i++) {
			int revenue = showRevenue3.get(i);
			int pcost = showPcost3.get(i);
			int profit = revenue - pcost;
			profit3.add(profit);
		}
		
		
		//변화율 계산
		//매출데이터
		double changeRateR1 = sumProfit(profit1); 
		double changeRateR2 = sumProfit(profit2); 
		double changeRateR3 = sumProfit(profit3);
		//비용데이터
		double changeRateC1 = profit1.get(profit1.size()-1)-profit1.get(0);
		double changeRateC2 = profit2.get(profit1.size()-1)-profit2.get(0);
		double changeRateC3 = profit3.get(profit1.size()-1)-profit3.get(0);
		//생산량 데이터
		double changeRateY1 = changeRate(showYield1);
		double changeRateY2 = changeRate(showYield2);
		double changeRateY3 = changeRate(showYield3);
		
		request.setAttribute("showRevenue1", showRevenue1);
		request.setAttribute("showPcost1", showPcost1);
		request.setAttribute("showYield1", showYield1);
		request.setAttribute("cropName1", cropName1);
		request.setAttribute("showRevenue2", showRevenue2);
		request.setAttribute("showPcost2", showPcost2);
		request.setAttribute("showYield2", showYield2);
		request.setAttribute("cropName2", cropName2);
		request.setAttribute("showRevenue3", showRevenue3);
		request.setAttribute("showPcost3", showPcost3);
		request.setAttribute("showYield3", showYield3);
		request.setAttribute("cropName3", cropName3);
		
//		request.setAttribute("changeRateR1", changeRateR1);
//		request.setAttribute("changeRateR2", changeRateR2);
//		request.setAttribute("changeRateR3", changeRateR3);
		request.setAttribute("changeRateC1", changeRateC1);
		request.setAttribute("changeRateC2", changeRateC2);
		request.setAttribute("changeRateC3", changeRateC3);
		request.setAttribute("changeRateY1", changeRateY1);
		request.setAttribute("changeRateY2", changeRateY2);
		request.setAttribute("changeRateY3", changeRateY3);
		
		System.out.println("cha1 :"+changeRateR1);
		System.out.println("cha2 : "+changeRateC2);
		System.out.println("cha3 : "+changeRateY3);
	}
	
	private double changeRate(ArrayList<Integer> list) {
		double result = 0.0;
		for(int i=1; i<list.size(); i++) {
			int prevVal = list.get(i-1);
			int currVal = list.get(i);
			
			if(prevVal == 0) {
				result += -100.0;
			}else {
				double temp = ((double)(currVal - prevVal) / prevVal * 100.0);
				result += temp;
			}
		}
		result = result/list.size();
		result = Math.round(result * 100) / 100.0;
		return result;
	}
	
	private int sumProfit(ArrayList<Integer> list) {
		int sum = 0;
		for(int i =0; i< list.size(); i++) {
			sum += list.get(i);
		}

		return sum/5;
	}
}
