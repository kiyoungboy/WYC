package com.WYC.recommendCommand;

import java.util.ArrayList;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.WYC.command.Command;
import com.WYC.dao.RecommendDao;
import com.WYC.dto.AreaCropsDto;
import com.WYC.dto.CropDto;
import com.WYC.dto.RecommendDto;
import com.WYC.dto.RecommendInfoDto;

public class Recommend implements Command{

	@Override
	public void execute(HttpServletRequest request, HttpServletResponse response) {
		// TODO Auto-generated method stub
		String areaData = request.getParameter("areaData"); 
		String conditionData = request.getParameter("conditionData");
		System.out.println(conditionData);
		String commaRemoveData = conditionData.replace(",", "");
		System.out.println(commaRemoveData);
		RecommendDao dao = new RecommendDao();
		
		ArrayList<Integer> selectedCrops = dao.findAreaCrops(areaData); 
		CropDto selectedCrop1 = dao.searchCrop2(selectedCrops.get(0));
		System.out.println(selectedCrop1.getCropCode());
		CropDto selectedCrop2 = dao.searchCrop2(selectedCrops.get(1));
		CropDto selectedCrop3 = dao.searchCrop2(selectedCrops.get(2));
		RecommendDto recommendCrop1 = dao.getRecommendPoint(selectedCrop1.getCropCode(), commaRemoveData);
		System.out.println(recommendCrop1.getCropName());
		RecommendDto recommendCrop2 = dao.getRecommendPoint(selectedCrop2.getCropCode(), commaRemoveData);
		RecommendDto recommendCrop3 = dao.getRecommendPoint(selectedCrop3.getCropCode(), commaRemoveData);
		
		CropDto resultDto = recommendResult(recommendCrop1, recommendCrop2, recommendCrop3);
		RecommendInfoDto finalResultDto = dao.searchRecommendInfo(resultDto.getCropCode());
		request.setAttribute("finalResultDto", finalResultDto);
	}
	public CropDto recommendResult(RecommendDto dto1, RecommendDto dto2, RecommendDto dto3) {
		CropDto dto = new CropDto();
		System.out.println(dto1.getCropCode());
		dto.setCropCode(dto1.getCropCode());
		dto.setCropName(dto1.getCropName());
		if(dto1.getRecommendPoint() <= dto2.getRecommendPoint()) {
			dto.setCropCode(dto2.getCropCode());
			dto.setCropName(dto2.getCropName());
		}
		if(dto1.getRecommendPoint() <= dto3.getRecommendPoint() && dto2.getRecommendPoint() <= dto3.getRecommendPoint()) {
			dto.setCropCode(dto3.getCropCode());
			dto.setCropName(dto3.getCropName());
		}		
		return dto;
	}
}
