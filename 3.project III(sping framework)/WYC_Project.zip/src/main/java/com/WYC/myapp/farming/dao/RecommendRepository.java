package com.WYC.myapp.farming.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;

import com.WYC.myapp.farming.dto.AreaCropsDto;
import com.WYC.myapp.farming.dto.CropDto;
import com.WYC.myapp.farming.dto.RecommendDto;
import com.WYC.myapp.farming.dto.RecommendInfoDto;

@Repository
public class RecommendRepository implements IRecommendRepository{

	@Autowired
	JdbcTemplate jdbcTemplate;
	
	@Override
	public List<AreaCropsDto> findAreaCrops(String areaName) {
		// TODO Auto-generated method stub
		String sql = "select area_code, area_name, area_crop1, area_crop2, area_crop3 from area_crops where area_name=?";
		return jdbcTemplate.query(sql, new RowMapper<AreaCropsDto>() {

			@Override
			public AreaCropsDto mapRow(ResultSet rs, int rowNum) throws SQLException {
				// TODO Auto-generated method stub
				AreaCropsDto dto = new AreaCropsDto();
				dto.setAreaCode(rs.getInt("area_code"));
				dto.setAreaName(rs.getString("area_name"));
				dto.setCropCode1(rs.getInt("area_crop1"));
				dto.setCropCode2(rs.getInt("area_crop2"));
				dto.setCropCode3(rs.getInt("area_crop3"));
				return dto;
			}
			
		}, areaName);
	}

	@Override
	public List<Integer> showRevenue(int cropCode) {
		// TODO Auto-generated method stub
		String sql;
		if(cropCode == 120001) {
			sql = "select revenue from crop_chives where year between 2017 and 2021";
		}else if(cropCode == 120002) {
			sql = "select revenue from crop_cucumber where year between 2017 and 2021";
		}else if(cropCode == 120003) {
			sql = "select revenue from crop_garlic where year between 2017 and 2021";
		}else if(cropCode == 120004) {
			sql = "select revenue from crop_grape where year between 2017 and 2021";
		}else if(cropCode == 120005) {
			sql = "select revenue from crop_greenonion where year between 2017 and 2021";
		}else if(cropCode == 120006) {
			sql = "select revenue from crop_kiwi where year between 2017 and 2021";
		}else if(cropCode == 120007) {
			sql = "select revenue from crop_onion where year between 2017 and 2021";
		}else if(cropCode == 120008) {
			sql = "select revenue from crop_peach where year between 2017 and 2021";
		}else if(cropCode == 120009) {
			sql = "select revenue from crop_pepper where year between 2017 and 2021";
		}else if(cropCode == 120010) {
			sql = "select revenue from crop_rice where year between 2017 and 2021";
		}else if(cropCode == 120011) {
			sql = "select revenue from crop_spinach where year between 2017 and 2021";
		}else if(cropCode == 120012) {
			sql = "select revenue from crop_spotato where year between 2017 and 2021";
		}else if(cropCode == 120013) {
			sql = "select revenue from crop_stberry where year between 2017 and 2021";
		}else{
			sql = "select revenue from crop_tomato where year between 2017 and 2021";
		}	
		return jdbcTemplate.query(sql, new RowMapper<Integer>() {

			@Override
			public Integer mapRow(ResultSet rs, int rowNum) throws SQLException {
				// TODO Auto-generated method stub
				int revenue = rs.getInt("revenue");
				return revenue;
			}
			
		});
	}

	@Override
	public List<Integer> showPcost(int cropCode) {
		// TODO Auto-generated method stub
		String sql;
		if(cropCode == 120001) {
			sql = "select pcost from crop_chives where year between 2017 and 2021";
		}else if(cropCode == 120002) {
			sql = "select pcost from crop_cucumber where year between 2017 and 2021";
		}else if(cropCode == 120003) {
			sql = "select pcost from crop_garlic where year between 2017 and 2021";
		}else if(cropCode == 120004) {
			sql = "select pcost from crop_grape where year between 2017 and 2021";
		}else if(cropCode == 120005) {
			sql = "select pcost from crop_greenonion where year between 2017 and 2021";
		}else if(cropCode == 120006) {
			sql = "select pcost from crop_kiwi where year between 2017 and 2021";
		}else if(cropCode == 120007) {
			sql = "select pcost from crop_onion where year between 2017 and 2021";
		}else if(cropCode == 120008) {
			sql = "select pcost from crop_peach where year between 2017 and 2021";
		}else if(cropCode == 120009) {
			sql = "select pcost from crop_pepper where year between 2017 and 2021";
		}else if(cropCode == 120010) {
			sql = "select pcost from crop_rice where year between 2017 and 2021";
		}else if(cropCode == 120011) {
			sql = "select pcost from crop_spinach where year between 2017 and 2021";
		}else if(cropCode == 120012) {
			sql = "select pcost from crop_spotato where year between 2017 and 2021";
		}else if(cropCode == 120013) {
			sql = "select pcost from crop_stberry where year between 2017 and 2021";
		}else{
			sql = "select pcost from crop_tomato where year between 2017 and 2021";
		}	
		return jdbcTemplate.query(sql, new RowMapper<Integer>() {

			@Override
			public Integer mapRow(ResultSet rs, int rowNum) throws SQLException {
				// TODO Auto-generated method stub
				int pcost = rs.getInt("pcost");
				return pcost;
			}
			
		});
	}

	@Override
	public List<Integer> showYield(int cropCode) {
		// TODO Auto-generated method stub
		String sql;
		if(cropCode == 120001) {
			sql = "select yield from crop_chives where year between 2017 and 2021";
		}else if(cropCode == 120002) {
			sql = "select yield from crop_cucumber where year between 2017 and 2021";
		}else if(cropCode == 120003) {
			sql = "select yield from crop_garlic where year between 2017 and 2021";
		}else if(cropCode == 120004) {
			sql = "select yield from crop_grape where year between 2017 and 2021";
		}else if(cropCode == 120005) {
			sql = "select yield from crop_greenonion where year between 2017 and 2021";
		}else if(cropCode == 120006) {
			sql = "select yield from crop_kiwi where year between 2017 and 2021";
		}else if(cropCode == 120007) {
			sql = "select yield from crop_onion where year between 2017 and 2021";
		}else if(cropCode == 120008) {
			sql = "select yield from crop_peach where year between 2017 and 2021";
		}else if(cropCode == 120009) {
			sql = "select yield from crop_pepper where year between 2017 and 2021";
		}else if(cropCode == 120010) {
			sql = "select yield from crop_rice where year between 2017 and 2021";
		}else if(cropCode == 120011) {
			sql = "select yield from crop_spinach where year between 2017 and 2021";
		}else if(cropCode == 120012) {
			sql = "select yield from crop_spotato where year between 2017 and 2021";
		}else if(cropCode == 120013) {
			sql = "select yield from crop_stberry where year between 2017 and 2021";
		}else{
			sql = "select yield from crop_tomato where year between 2017 and 2021";
		}	
		return jdbcTemplate.query(sql, new RowMapper<Integer>() {

			@Override
			public Integer mapRow(ResultSet rs, int rowNum) throws SQLException {
				// TODO Auto-generated method stub
				int yield = rs.getInt("yield");
				return yield;
			}
			
		});
	}

	@Override
	public String showCrop(int cropCode) {
		// TODO Auto-generated method stub
		String sql = "select crop_name from crop_code where crop_code=?";
		return jdbcTemplate.queryForObject(sql, new RowMapper<String>() {

			@Override
			public String mapRow(ResultSet rs, int rowNum) throws SQLException {
				// TODO Auto-generated method stub
				String cropName = rs.getString("crop_name");
				return cropName;
			}
			
		}, cropCode);
	}

	@Override
	public CropDto searchCrop2(int searchCode) {
		// TODO Auto-generated method stub
		String sql = "select crop_code, crop_name from crop_code where crop_code=?";
		return jdbcTemplate.queryForObject(sql, new RowMapper<CropDto>() {

			@Override
			public CropDto mapRow(ResultSet rs, int rowNum) throws SQLException {
				// TODO Auto-generated method stub
				CropDto dto = new CropDto();
				dto.setCropCode(rs.getInt("crop_code"));
				dto.setCropName(rs.getString("crop_name"));
				return dto;
			}
			
		}, searchCode);
	}

	@Override
	public RecommendDto getRecommendPoint(int selectedCrop, String commaRemoveData) {
		// TODO Auto-generated method stub
		String sql = "select crop_code, crop_name, "+commaRemoveData+"_point from recommend_point where crop_code = ?";
		return jdbcTemplate.queryForObject(sql, new RowMapper<RecommendDto>(){

			@Override
			public RecommendDto mapRow(ResultSet rs, int rowNum) throws SQLException {
				// TODO Auto-generated method stub
				RecommendDto dto = new RecommendDto();
				dto.setCropCode(rs.getInt("crop_code"));
				dto.setCropName(rs.getString("crop_name"));
				dto.setRecommendPoint(rs.getInt(commaRemoveData+"_point"));
				return dto;
			}
			
		}, selectedCrop);
	}

	@Override
	public RecommendInfoDto searchRecommendInfo(int cropCode) {
		// TODO Auto-generated method stub
		String sql = "select crop_code, crop_name, revenue, pcost, work_time from recommend_info where crop_code=?";
		return jdbcTemplate.queryForObject(sql, new RowMapper<RecommendInfoDto>() {

			@Override
			public RecommendInfoDto mapRow(ResultSet rs, int rowNum) throws SQLException {
				// TODO Auto-generated method stub
				RecommendInfoDto dto = new RecommendInfoDto();
				dto.setCropCode(rs.getInt("crop_code"));
				dto.setCropName(rs.getString("crop_name"));
				dto.setCropRevenue(rs.getInt("revenue"));
				dto.setCropPcost(rs.getInt("pcost"));
				dto.setCropWorkTime(rs.getInt("work_time"));
				return dto;
			}
			
		}, cropCode);
	}

}
