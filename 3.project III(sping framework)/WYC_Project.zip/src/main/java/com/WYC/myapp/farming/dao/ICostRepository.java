package com.WYC.myapp.farming.dao;

import java.util.ArrayList;
import java.util.List;

import com.WYC.myapp.farming.dto.AreaSiDoDto;
import com.WYC.myapp.farming.dto.AreaSiGunGuDto;
import com.WYC.myapp.farming.dto.CropCostDto;
import com.WYC.myapp.farming.dto.CropDto;
import com.WYC.myapp.farming.dto.PolicyDto;

public interface ICostRepository {
	public CropDto searchCrop(String searchName);
	public AreaSiDoDto searchSiDo(String searchSiDo);
	public AreaSiGunGuDto searchSiGunGu(String searchSiGunGu);
	public CropCostDto serachCost(int searchCost);
	public List<PolicyDto> showConditionList(int siGunGuCode, int age, int farmingPeriod);
	public List<PolicyDto> showList();
	public PolicyDto selectSubsidy(String checkedPolicy);
}
