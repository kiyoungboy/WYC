package com.WYC.myapp.farming.controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.WYC.myapp.farming.dto.FarmAreaCropDto;
import com.WYC.myapp.farming.dto.FarmCropAreaDto;
import com.WYC.myapp.farming.dto.FarmCropDto;
import com.WYC.myapp.farming.dto.FarmCropProfileDto;
import com.WYC.myapp.farming.service.IRevenueService;

@Controller
public class RevenueController {
	
	@Autowired
	IRevenueService revenueService;
	
	@RequestMapping(value="revenue1")
	public String reveunue1(Model model) {
		List<FarmCropDto> cropList = revenueService.cropList();
		model.addAttribute("cropList", cropList);
		return "revenue1";
	}
	@RequestMapping(value="revenue2")
	public String revenue2() {
		return "revenue2";
	}
	
	@PostMapping("cropArea")
	@ResponseBody
	public List<FarmCropAreaDto> cropArea(@RequestParam(value="crop") String selectCrop, Model model) {
		List<FarmCropAreaDto> list = revenueService.cropAreaList(selectCrop);
		return list;
	}
	
	@PostMapping("getCropProfile")
	@ResponseBody
	public FarmCropProfileDto cropProfile(@RequestParam(value="selectCrop") String selectCrop, HttpServletRequest request, Model model) {
		FarmCropProfileDto cropProfile = revenueService.getCropProfile(selectCrop);
        return cropProfile;
	}
	
	@PostMapping("salesText")
	@ResponseBody
	public List<Integer> salesText(@RequestParam(value="selectCrop") String selectCrop, 
										   @RequestParam(value="selectArea") String selectArea, 
										   Model model) {
		List<Integer> revenues = revenueService.findRevenue(selectCrop);
        return revenues;
	}
	
	@PostMapping("getCropHpriceYield")
	@ResponseBody
	public List<List<String>> cropHpriceYield(@RequestParam(value="selectCrop") String selectCrop, HttpServletRequest request, Model model) {
		
		List<List<String>> yearHpriceYield = revenueService.getHpriceYield(selectCrop);
		
        return yearHpriceYield;
	}
	
	@RequestMapping(value="checkCost")
	public String checkCost(@RequestParam(value="selectCropKor") String selectCropKor,
											@RequestParam(value="selectAreaKor") String selectAreaKor,
											@RequestParam(value="salesResult") String salesResult,
											Model model){
		int getSalesResult = Integer.parseInt(salesResult.replaceAll(",", ""));
		model.addAttribute("salesResult", getSalesResult);
		
		return "policyList";
	}
	
	@PostMapping("getAreaCropList")
	@ResponseBody
	public List<FarmAreaCropDto> getAreaCropList(@RequestParam(value="areaCrop") String areaCrop, Model model) {
		List<FarmAreaCropDto> list = revenueService.getAreaCrop(areaCrop);
		return list;
	}
	
}
