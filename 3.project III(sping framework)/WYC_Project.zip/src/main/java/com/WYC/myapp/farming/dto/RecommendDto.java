package com.WYC.myapp.farming.dto;

public class RecommendDto {
	private int cropCode;
	private String cropName;
	private int recommendPoint;
	
	public RecommendDto() {}
	public RecommendDto(int cropCode, String cropName, int recommendPoint ) {
		this.cropCode = cropCode;
		this.cropName = cropName;
		this.recommendPoint = recommendPoint;
	}
	public int getCropCode() {
		return cropCode;
	}
	public void setCropCode(int cropCode) {
		this.cropCode = cropCode;
	}
	public String getCropName() {
		return cropName;
	}
	public void setCropName(String cropName) {
		this.cropName = cropName;
	}
	public int getRecommendPoint() {
		return recommendPoint;
	}
	public void setRecommendPoint(int recommendPoint) {
		this.recommendPoint = recommendPoint;
	}
	
}
