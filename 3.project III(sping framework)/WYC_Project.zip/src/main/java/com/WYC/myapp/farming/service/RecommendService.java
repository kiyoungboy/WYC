package com.WYC.myapp.farming.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.WYC.myapp.farming.dao.IRecommendRepository;
import com.WYC.myapp.farming.dto.AreaCropsDto;
import com.WYC.myapp.farming.dto.CropDto;
import com.WYC.myapp.farming.dto.RecommendDto;
import com.WYC.myapp.farming.dto.RecommendInfoDto;

@Service
public class RecommendService implements IRecommendService{
	
	@Autowired
	IRecommendRepository recommendRepository;

	@Override
	public List<AreaCropsDto> findAreaCrops(String areaName) {
		// TODO Auto-generated method stub
		return recommendRepository.findAreaCrops(areaName);
	}

	@Override
	public List<Integer> showRevenue(int cropCode) {
		// TODO Auto-generated method stub
		return recommendRepository.showRevenue(cropCode);
	}

	@Override
	public List<Integer> showPcost(int cropCode) {
		// TODO Auto-generated method stub
		return recommendRepository.showPcost(cropCode);
	}

	@Override
	public List<Integer> showYield(int cropCode) {
		// TODO Auto-generated method stub
		return recommendRepository.showYield(cropCode);
	}

	@Override
	public String showCrop(int cropCode) {
		// TODO Auto-generated method stub
		return recommendRepository.showCrop(cropCode);
	}

	@Override
	public CropDto searchCrop2(int searchCode) {
		// TODO Auto-generated method stub
		return recommendRepository.searchCrop2(searchCode);
	}

	@Override
	public RecommendDto getRecommendPoint(int selectedCrop, String commaRemoveData) {
		// TODO Auto-generated method stub
		return recommendRepository.getRecommendPoint(selectedCrop, commaRemoveData);
	}

	@Override
	public RecommendInfoDto searchRecommendInfo(int cropCode) {
		// TODO Auto-generated method stub
		return recommendRepository.searchRecommendInfo(cropCode);
	}

}
