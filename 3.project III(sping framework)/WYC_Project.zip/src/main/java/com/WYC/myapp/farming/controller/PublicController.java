package com.WYC.myapp.farming.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class PublicController {

		@RequestMapping(value="festival")
		public String festival() {
			return "festival";
		}
		
		@RequestMapping(value="login")
		public String login() {
			return "login";
		}
		
		@RequestMapping(value="find_id")
		public String findId() {
			return "find_id";
		}
		
		@RequestMapping(value="find_pw")
		public String findPw() {
			return "find_pw";
		}
		
		@RequestMapping(value="joinMember")
		public String joinMember() {
			return "joinMember";
		}
		
		@RequestMapping(value="serviceEsidence")
		public String serviceEsidence() {
			return "serviceEsidence";
		}
		
		@RequestMapping(value="serviceEsidence_detail")
		public String serviceEsidenceDetail() {
			return "serviceEsidence_detail";
		}
		
}
